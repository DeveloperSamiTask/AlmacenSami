﻿namespace Microsell_Lite.Compras
{
    partial class Frm_Compras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Compras));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pnl_titu = new System.Windows.Forms.Panel();
            this.btn_minimi = new System.Windows.Forms.Button();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.gru_det = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.btn_procesar = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.pnl_sinProd = new System.Windows.Forms.Panel();
            this.btn_Nuevo_buscarProd = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.ElDivider3 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.Label17 = new System.Windows.Forms.Label();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbo_provee = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NroFisico = new System.Windows.Forms.TextBox();
            this.elGroupBox1 = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator5 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator6 = new Bunifu.Framework.UI.BunifuSeparator();
            this.lsv_Det = new System.Windows.Forms.ListView();
            this.label10 = new System.Windows.Forms.Label();
            this.cbo_tipoPago = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtp_FechaCom = new System.Windows.Forms.DateTimePicker();
            this.txt_IdComp = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dtp_FechaVenc = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.cbo_tipoDoc = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_obser = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.bunifuSeparator7 = new Bunifu.Framework.UI.BunifuSeparator();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.lbl_igv = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbl_TotalPagar = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.bt_add = new System.Windows.Forms.Button();
            this.bt_editPre = new System.Windows.Forms.Button();
            this.bt_editCant = new System.Windows.Forms.Button();
            this.bt_Delete = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pnl_titu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gru_det)).BeginInit();
            this.gru_det.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_procesar)).BeginInit();
            this.pnl_sinProd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Nuevo_buscarProd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElDivider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox1)).BeginInit();
            this.elGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pnl_titu
            // 
            this.pnl_titu.BackColor = System.Drawing.Color.DimGray;
            this.pnl_titu.Controls.Add(this.btn_minimi);
            this.pnl_titu.Controls.Add(this.btn_cerrar);
            this.pnl_titu.Controls.Add(this.label1);
            this.pnl_titu.Controls.Add(this.pnl_sinProd);
            this.pnl_titu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_titu.Location = new System.Drawing.Point(0, 0);
            this.pnl_titu.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_titu.Name = "pnl_titu";
            this.pnl_titu.Size = new System.Drawing.Size(1071, 40);
            this.pnl_titu.TabIndex = 1;
            this.pnl_titu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnl_titu_MouseMove);
            // 
            // btn_minimi
            // 
            this.btn_minimi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minimi.FlatAppearance.BorderSize = 0;
            this.btn_minimi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minimi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_minimi.ForeColor = System.Drawing.Color.White;
            this.btn_minimi.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimi.Image")));
            this.btn_minimi.Location = new System.Drawing.Point(970, 3);
            this.btn_minimi.Margin = new System.Windows.Forms.Padding(4);
            this.btn_minimi.Name = "btn_minimi";
            this.btn_minimi.Size = new System.Drawing.Size(35, 31);
            this.btn_minimi.TabIndex = 7;
            this.btn_minimi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_minimi.UseVisualStyleBackColor = true;
            this.btn_minimi.Click += new System.EventHandler(this.btn_minimi_Click);
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cerrar.FlatAppearance.BorderSize = 0;
            this.btn_cerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cerrar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cerrar.ForeColor = System.Drawing.Color.White;
            this.btn_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("btn_cerrar.Image")));
            this.btn_cerrar.Location = new System.Drawing.Point(1029, 4);
            this.btn_cerrar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(31, 30);
            this.btn_cerrar.TabIndex = 6;
            this.btn_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registro de Compras";
            // 
            // gru_det
            // 
            this.gru_det.BackgroundStyle.GradientAngle = 45F;
            this.gru_det.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.gru_det.BorderStyle.SolidColor = System.Drawing.Color.SkyBlue;
            this.gru_det.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.gru_det.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.gru_det.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.gru_det.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.gru_det.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.Window;
            this.gru_det.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gru_det.CaptionStyle.TextStyle.TextType = Klik.Windows.Forms.v1.Common.TextTypes.BlockShadow;
            this.gru_det.CaptionStyle.Visible = false;
            this.gru_det.CaptionStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.gru_det.Controls.Add(this.bt_Delete);
            this.gru_det.Controls.Add(this.lsv_Det);
            this.gru_det.Controls.Add(this.bt_editCant);
            this.gru_det.Controls.Add(this.bunifuSeparator6);
            this.gru_det.Controls.Add(this.bt_editPre);
            this.gru_det.Controls.Add(this.bunifuSeparator5);
            this.gru_det.Controls.Add(this.bt_add);
            this.gru_det.Controls.Add(this.bunifuSeparator4);
            this.gru_det.Controls.Add(this.bunifuSeparator3);
            this.gru_det.Controls.Add(this.label9);
            this.gru_det.Controls.Add(this.label8);
            this.gru_det.Controls.Add(this.label6);
            this.gru_det.Controls.Add(this.label7);
            this.gru_det.Controls.Add(this.label5);
            this.gru_det.Controls.Add(this.bunifuSeparator2);
            this.gru_det.Location = new System.Drawing.Point(7, 48);
            this.gru_det.Margin = new System.Windows.Forms.Padding(4);
            this.gru_det.Name = "gru_det";
            this.gru_det.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gru_det.Size = new System.Drawing.Size(783, 280);
            this.gru_det.TabIndex = 2;
            this.gru_det.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btn_procesar
            // 
            this.btn_procesar.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_procesar.BackgroundStyle.SolidColor = System.Drawing.Color.DodgerBlue;
            this.btn_procesar.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.EdgeRadius = 7;
            this.btn_procesar.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.btn_procesar.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            this.btn_procesar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_procesar.DropDownArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.btn_procesar.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_procesar.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btn_procesar.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_procesar.Location = new System.Drawing.Point(36, 369);
            this.btn_procesar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_procesar.Name = "btn_procesar";
            this.btn_procesar.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernBlack;
            this.btn_procesar.Size = new System.Drawing.Size(199, 54);
            this.btn_procesar.TabIndex = 6;
            this.btn_procesar.TextStyle.Font = new System.Drawing.Font("Oxygen", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_procesar.TextStyle.ForeColor = System.Drawing.Color.White;
            this.btn_procesar.TextStyle.Text = "Procesar Compra";
            this.btn_procesar.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_procesar.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.Custom;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(-20, 322);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(291, 26);
            this.bunifuSeparator1.TabIndex = 7;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // pnl_sinProd
            // 
            this.pnl_sinProd.BackColor = System.Drawing.Color.SkyBlue;
            this.pnl_sinProd.Controls.Add(this.btn_Nuevo_buscarProd);
            this.pnl_sinProd.Controls.Add(this.ElDivider3);
            this.pnl_sinProd.Controls.Add(this.Label17);
            this.pnl_sinProd.Controls.Add(this.PictureBox3);
            this.pnl_sinProd.ForeColor = System.Drawing.Color.Black;
            this.pnl_sinProd.Location = new System.Drawing.Point(530, 0);
            this.pnl_sinProd.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_sinProd.Name = "pnl_sinProd";
            this.pnl_sinProd.Size = new System.Drawing.Size(41, 37);
            this.pnl_sinProd.TabIndex = 480;
            this.pnl_sinProd.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_sinProd_Paint);
            // 
            // btn_Nuevo_buscarProd
            // 
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientAngle = 0F;
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientEndColor = System.Drawing.Color.OrangeRed;
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_Nuevo_buscarProd.BackgroundStyle.SolidColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Nuevo_buscarProd.BorderStyle.SolidColor = System.Drawing.Color.DodgerBlue;
            this.btn_Nuevo_buscarProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Nuevo_buscarProd.DropDownArrowColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.EnableThemes = false;
            this.btn_Nuevo_buscarProd.FlashStyle.GradientEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.FlashStyle.GradientStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_Nuevo_buscarProd.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Nuevo_buscarProd.Location = new System.Drawing.Point(657, 456);
            this.btn_Nuevo_buscarProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Nuevo_buscarProd.Name = "btn_Nuevo_buscarProd";
            this.btn_Nuevo_buscarProd.Size = new System.Drawing.Size(423, 73);
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundGradientEndColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundGradientStartColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundSolidColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderGradientEndColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderGradientStartColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderSolidColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.TabIndex = 407;
            this.btn_Nuevo_buscarProd.TextStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.TextStyle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nuevo_buscarProd.TextStyle.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btn_Nuevo_buscarProd.TextStyle.Text = "Buscar Productos | Nuevo [F1]";
            this.btn_Nuevo_buscarProd.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Nuevo_buscarProd.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.Custom;
            // 
            // ElDivider3
            // 
            this.ElDivider3.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.Center;
            this.ElDivider3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ElDivider3.Location = new System.Drawing.Point(309, 358);
            this.ElDivider3.Margin = new System.Windows.Forms.Padding(4);
            this.ElDivider3.Name = "ElDivider3";
            this.ElDivider3.Size = new System.Drawing.Size(1059, 34);
            this.ElDivider3.TabIndex = 408;
            this.ElDivider3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.BackColor = System.Drawing.Color.Transparent;
            this.Label17.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.ForeColor = System.Drawing.Color.White;
            this.Label17.Location = new System.Drawing.Point(579, 304);
            this.Label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(347, 32);
            this.Label17.TabIndex = 405;
            this.Label17.Text = "Tu carrito de Ventas está Vacio";
            // 
            // PictureBox3
            // 
            this.PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox3.ForeColor = System.Drawing.Color.Black;
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(789, 175);
            this.PictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(96, 96);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PictureBox3.TabIndex = 406;
            this.PictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 356);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 19);
            this.label2.TabIndex = 481;
            this.label2.Text = "Proveedor:";
            // 
            // cbo_provee
            // 
            this.cbo_provee.FormattingEnabled = true;
            this.cbo_provee.Location = new System.Drawing.Point(149, 354);
            this.cbo_provee.Name = "cbo_provee";
            this.cbo_provee.Size = new System.Drawing.Size(507, 27);
            this.cbo_provee.TabIndex = 482;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 399);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 19);
            this.label3.TabIndex = 483;
            this.label3.Text = "Nro Doc. Fisico:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_NroFisico
            // 
            this.txt_NroFisico.Location = new System.Drawing.Point(149, 394);
            this.txt_NroFisico.Name = "txt_NroFisico";
            this.txt_NroFisico.Size = new System.Drawing.Size(140, 26);
            this.txt_NroFisico.TabIndex = 484;
            // 
            // elGroupBox1
            // 
            this.elGroupBox1.BackgroundStyle.GradientAngle = 45F;
            this.elGroupBox1.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.BackgroundStyle.SolidColor = System.Drawing.Color.WhiteSmoke;
            this.elGroupBox1.BorderStyle.SolidColor = System.Drawing.Color.SkyBlue;
            this.elGroupBox1.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.elGroupBox1.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elGroupBox1.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.elGroupBox1.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.elGroupBox1.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.Window;
            this.elGroupBox1.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elGroupBox1.CaptionStyle.TextStyle.TextType = Klik.Windows.Forms.v1.Common.TextTypes.BlockShadow;
            this.elGroupBox1.CaptionStyle.Visible = false;
            this.elGroupBox1.CaptionStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elGroupBox1.Controls.Add(this.lbl_TotalPagar);
            this.elGroupBox1.Controls.Add(this.label23);
            this.elGroupBox1.Controls.Add(this.lbl_igv);
            this.elGroupBox1.Controls.Add(this.label21);
            this.elGroupBox1.Controls.Add(this.lbl_subtotal);
            this.elGroupBox1.Controls.Add(this.label18);
            this.elGroupBox1.Controls.Add(this.label16);
            this.elGroupBox1.Controls.Add(this.btn_procesar);
            this.elGroupBox1.Controls.Add(this.bunifuSeparator1);
            this.elGroupBox1.Controls.Add(this.bunifuSeparator7);
            this.elGroupBox1.Location = new System.Drawing.Point(809, 48);
            this.elGroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.elGroupBox1.Name = "elGroupBox1";
            this.elGroupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elGroupBox1.Size = new System.Drawing.Size(261, 498);
            this.elGroupBox1.TabIndex = 485;
            this.elGroupBox1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DodgerBlue;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Location = new System.Drawing.Point(0, 581);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1071, 3);
            this.label4.TabIndex = 486;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(85, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(377, 23);
            this.label7.TabIndex = 9;
            this.label7.Text = "Descripcion del Producto";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(5, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Id Prod.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(542, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 23);
            this.label6.TabIndex = 10;
            this.label6.Text = "Pre Unit.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(633, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 23);
            this.label8.TabIndex = 11;
            this.label8.Text = "Importe";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(460, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 23);
            this.label9.TabIndex = 12;
            this.label9.Text = "Cant.";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(130)))), ((int)(((byte)(180)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(0, 19);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(783, 20);
            this.bunifuSeparator2.TabIndex = 13;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.Gainsboro;
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(78, 3);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(11, 23);
            this.bunifuSeparator3.TabIndex = 14;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = true;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(446, 3);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(9, 9, 9, 9);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(16, 23);
            this.bunifuSeparator4.TabIndex = 15;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = true;
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(536, 0);
            this.bunifuSeparator5.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(13, 26);
            this.bunifuSeparator5.TabIndex = 16;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = true;
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(629, 3);
            this.bunifuSeparator6.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(10, 23);
            this.bunifuSeparator6.TabIndex = 17;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = true;
            // 
            // lsv_Det
            // 
            this.lsv_Det.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsv_Det.HideSelection = false;
            this.lsv_Det.Location = new System.Drawing.Point(3, 30);
            this.lsv_Det.Name = "lsv_Det";
            this.lsv_Det.Size = new System.Drawing.Size(739, 239);
            this.lsv_Det.TabIndex = 18;
            this.lsv_Det.UseCompatibleStateImageBehavior = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 434);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 19);
            this.label10.TabIndex = 487;
            this.label10.Text = "Tipo Pago";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbo_tipoPago
            // 
            this.cbo_tipoPago.FormattingEnabled = true;
            this.cbo_tipoPago.Location = new System.Drawing.Point(149, 426);
            this.cbo_tipoPago.Name = "cbo_tipoPago";
            this.cbo_tipoPago.Size = new System.Drawing.Size(140, 27);
            this.cbo_tipoPago.TabIndex = 488;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 474);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 19);
            this.label11.TabIndex = 489;
            this.label11.Text = "Fecha Compra";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dtp_FechaCom
            // 
            this.dtp_FechaCom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaCom.Location = new System.Drawing.Point(149, 470);
            this.dtp_FechaCom.Name = "dtp_FechaCom";
            this.dtp_FechaCom.Size = new System.Drawing.Size(140, 26);
            this.dtp_FechaCom.TabIndex = 490;
            // 
            // txt_IdComp
            // 
            this.txt_IdComp.Enabled = false;
            this.txt_IdComp.Location = new System.Drawing.Point(516, 392);
            this.txt_IdComp.Name = "txt_IdComp";
            this.txt_IdComp.Size = new System.Drawing.Size(140, 26);
            this.txt_IdComp.TabIndex = 492;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(394, 397);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 19);
            this.label12.TabIndex = 491;
            this.label12.Text = "Primary Key";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dtp_FechaVenc
            // 
            this.dtp_FechaVenc.Enabled = false;
            this.dtp_FechaVenc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaVenc.Location = new System.Drawing.Point(516, 428);
            this.dtp_FechaVenc.Name = "dtp_FechaVenc";
            this.dtp_FechaVenc.Size = new System.Drawing.Size(140, 26);
            this.dtp_FechaVenc.TabIndex = 494;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(394, 432);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 19);
            this.label13.TabIndex = 493;
            this.label13.Text = "Fecha Vencim.";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbo_tipoDoc
            // 
            this.cbo_tipoDoc.FormattingEnabled = true;
            this.cbo_tipoDoc.Location = new System.Drawing.Point(516, 466);
            this.cbo_tipoDoc.Name = "cbo_tipoDoc";
            this.cbo_tipoDoc.Size = new System.Drawing.Size(140, 27);
            this.cbo_tipoDoc.TabIndex = 496;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(392, 470);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 19);
            this.label14.TabIndex = 495;
            this.label14.Text = "Tipo Documnto.";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_obser
            // 
            this.txt_obser.Location = new System.Drawing.Point(149, 502);
            this.txt_obser.Name = "txt_obser";
            this.txt_obser.Size = new System.Drawing.Size(507, 26);
            this.txt_obser.TabIndex = 498;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 507);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 19);
            this.label15.TabIndex = 497;
            this.label15.Text = "Observacion:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(149, 545);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(140, 23);
            this.checkBox1.TabIndex = 499;
            this.checkBox1.Text = "Recibí Conforme";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Oxygen", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label16.Location = new System.Drawing.Point(85, 15);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 24);
            this.label16.TabIndex = 484;
            this.label16.Text = "Importes ";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(79, 75);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(97, 19);
            this.label18.TabIndex = 490;
            this.label18.Text = "Sub Total S/.";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator7.LineThickness = 1;
            this.bunifuSeparator7.Location = new System.Drawing.Point(39, 45);
            this.bunifuSeparator7.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(176, 12);
            this.bunifuSeparator7.TabIndex = 491;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.Font = new System.Drawing.Font("Oxygen", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtotal.ForeColor = System.Drawing.Color.Tomato;
            this.lbl_subtotal.Location = new System.Drawing.Point(50, 105);
            this.lbl_subtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(126, 27);
            this.lbl_subtotal.TabIndex = 492;
            this.lbl_subtotal.Text = "00.00";
            this.lbl_subtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_igv
            // 
            this.lbl_igv.Font = new System.Drawing.Font("Oxygen", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_igv.ForeColor = System.Drawing.Color.Tomato;
            this.lbl_igv.Location = new System.Drawing.Point(50, 178);
            this.lbl_igv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_igv.Name = "lbl_igv";
            this.lbl_igv.Size = new System.Drawing.Size(126, 27);
            this.lbl_igv.TabIndex = 494;
            this.lbl_igv.Text = "00.00";
            this.lbl_igv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(126, 146);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 19);
            this.label21.TabIndex = 493;
            this.label21.Text = "Igv S/";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_TotalPagar
            // 
            this.lbl_TotalPagar.Font = new System.Drawing.Font("Oxygen", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPagar.ForeColor = System.Drawing.Color.Tomato;
            this.lbl_TotalPagar.Location = new System.Drawing.Point(30, 261);
            this.lbl_TotalPagar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TotalPagar.Name = "lbl_TotalPagar";
            this.lbl_TotalPagar.Size = new System.Drawing.Size(156, 37);
            this.lbl_TotalPagar.TabIndex = 496;
            this.lbl_TotalPagar.Text = "00.00";
            this.lbl_TotalPagar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(52, 228);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(124, 19);
            this.label23.TabIndex = 495;
            this.label23.Text = "Total Compra S/.";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bt_add
            // 
            this.bt_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_add.FlatAppearance.BorderSize = 0;
            this.bt_add.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_add.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_add.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_add.ForeColor = System.Drawing.Color.White;
            this.bt_add.Image = ((System.Drawing.Image)(resources.GetObject("bt_add.Image")));
            this.bt_add.Location = new System.Drawing.Point(749, 38);
            this.bt_add.Margin = new System.Windows.Forms.Padding(4);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(26, 26);
            this.bt_add.TabIndex = 500;
            this.bt_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_add, "Agregar mas Productos [F4]");
            this.bt_add.UseVisualStyleBackColor = true;
            // 
            // bt_editPre
            // 
            this.bt_editPre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_editPre.FlatAppearance.BorderSize = 0;
            this.bt_editPre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editPre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editPre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_editPre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_editPre.ForeColor = System.Drawing.Color.White;
            this.bt_editPre.Image = ((System.Drawing.Image)(resources.GetObject("bt_editPre.Image")));
            this.bt_editPre.Location = new System.Drawing.Point(749, 83);
            this.bt_editPre.Margin = new System.Windows.Forms.Padding(4);
            this.bt_editPre.Name = "bt_editPre";
            this.bt_editPre.Size = new System.Drawing.Size(26, 26);
            this.bt_editPre.TabIndex = 501;
            this.bt_editPre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_editPre, "Editar Precio ");
            this.bt_editPre.UseVisualStyleBackColor = true;
            // 
            // bt_editCant
            // 
            this.bt_editCant.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_editCant.FlatAppearance.BorderSize = 0;
            this.bt_editCant.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editCant.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editCant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_editCant.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_editCant.ForeColor = System.Drawing.Color.White;
            this.bt_editCant.Image = ((System.Drawing.Image)(resources.GetObject("bt_editCant.Image")));
            this.bt_editCant.Location = new System.Drawing.Point(749, 129);
            this.bt_editCant.Margin = new System.Windows.Forms.Padding(4);
            this.bt_editCant.Name = "bt_editCant";
            this.bt_editCant.Size = new System.Drawing.Size(26, 26);
            this.bt_editCant.TabIndex = 502;
            this.bt_editCant.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_editCant, "Editar Cantidad - Subir o Bajar");
            this.bt_editCant.UseVisualStyleBackColor = true;
            // 
            // bt_Delete
            // 
            this.bt_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_Delete.FlatAppearance.BorderSize = 0;
            this.bt_Delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_Delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Delete.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Delete.ForeColor = System.Drawing.Color.White;
            this.bt_Delete.Image = ((System.Drawing.Image)(resources.GetObject("bt_Delete.Image")));
            this.bt_Delete.Location = new System.Drawing.Point(749, 175);
            this.bt_Delete.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Delete.Name = "bt_Delete";
            this.bt_Delete.Size = new System.Drawing.Size(26, 26);
            this.bt_Delete.TabIndex = 503;
            this.bt_Delete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_Delete, "Quitar Producto del carrito");
            this.bt_Delete.UseVisualStyleBackColor = true;
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // Frm_Compras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1071, 584);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.txt_obser);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cbo_tipoDoc);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dtp_FechaVenc);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_IdComp);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dtp_FechaCom);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbo_tipoPago);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.elGroupBox1);
            this.Controls.Add(this.txt_NroFisico);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbo_provee);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gru_det);
            this.Controls.Add(this.pnl_titu);
            this.Font = new System.Drawing.Font("Oxygen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Compras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ingreso de Compras";
            this.Load += new System.EventHandler(this.Frm_Ventana_Ventas_Load);
            this.pnl_titu.ResumeLayout(false);
            this.pnl_titu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gru_det)).EndInit();
            this.gru_det.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_procesar)).EndInit();
            this.pnl_sinProd.ResumeLayout(false);
            this.pnl_sinProd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Nuevo_buscarProd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElDivider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox1)).EndInit();
            this.elGroupBox1.ResumeLayout(false);
            this.elGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel pnl_titu;
        private System.Windows.Forms.Button btn_minimi;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.Label label1;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox gru_det;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btn_procesar;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        internal System.Windows.Forms.Panel pnl_sinProd;
        internal Klik.Windows.Forms.v1.EntryLib.ELButton btn_Nuevo_buscarProd;
        internal Klik.Windows.Forms.v1.EntryLib.ELDivider ElDivider3;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.PictureBox PictureBox3;
        private System.Windows.Forms.TextBox txt_NroFisico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbo_provee;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox elGroupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator6;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator5;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.ListView lsv_Det;
        private System.Windows.Forms.DateTimePicker dtp_FechaCom;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbo_tipoPago;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txt_obser;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbo_tipoDoc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtp_FechaVenc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_IdComp;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_TotalPagar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_igv;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator7;
        private System.Windows.Forms.Button bt_Delete;
        private System.Windows.Forms.Button bt_editCant;
        private System.Windows.Forms.Button bt_editPre;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}