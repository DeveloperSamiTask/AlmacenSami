﻿namespace Microsell_Lite.Cotizacion
{
    partial class Frm_Crear_Ventas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Crear_Ventas));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle6 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle5 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle3 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle4 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pnl_titu = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_minimi = new System.Windows.Forms.Button();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_sinProd = new System.Windows.Forms.Panel();
            this.pnl_subtitu = new System.Windows.Forms.Panel();
            this.chkCapital = new System.Windows.Forms.CheckBox();
            this.btn_Nuevo_buscarProd = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.ElDivider3 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.Label17 = new System.Windows.Forms.Label();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.gru_det = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.bt_Delete = new System.Windows.Forms.Button();
            this.lsv_Det = new System.Windows.Forms.ListView();
            this.bt_editPre = new System.Windows.Forms.Button();
            this.bt_add = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_TotalItem = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.elDivider2 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.btn_procesar = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txt_NroCotiza = new System.Windows.Forms.TextBox();
            this.gru_numeros = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.elDivider5 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.elDivider1 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.lbl_totalGanancia = new System.Windows.Forms.Label();
            this.lbl_Frank = new System.Windows.Forms.Label();
            this.bunifuSeparator9 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator8 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label23 = new System.Windows.Forms.Label();
            this.lbl_igv = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.elDivider4 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.lbl_TotalPagar = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.dtp_FechaEmi = new System.Windows.Forms.DateTimePicker();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lbl_BusClien = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lbl_son = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txt_cliente = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txt_nroPed = new System.Windows.Forms.TextBox();
            this.lbl_idcliente = new System.Windows.Forms.Label();
            this.elGroupBox1 = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.elLabel4 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.elLabel3 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.elLabel2 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.elLabel1 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.pnl_titu.SuspendLayout();
            this.pnl_sinProd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Nuevo_buscarProd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElDivider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gru_det)).BeginInit();
            this.gru_det.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_procesar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gru_numeros)).BeginInit();
            this.gru_numeros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TotalPagar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_son)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox1)).BeginInit();
            this.elGroupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 15;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pnl_titu
            // 
            this.pnl_titu.BackColor = System.Drawing.Color.DimGray;
            this.pnl_titu.Controls.Add(this.button3);
            this.pnl_titu.Controls.Add(this.button2);
            this.pnl_titu.Controls.Add(this.button1);
            this.pnl_titu.Controls.Add(this.label3);
            this.pnl_titu.Controls.Add(this.bunifuMaterialTextbox1);
            this.pnl_titu.Controls.Add(this.btn_minimi);
            this.pnl_titu.Controls.Add(this.btn_cerrar);
            this.pnl_titu.Controls.Add(this.label1);
            this.pnl_titu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_titu.Location = new System.Drawing.Point(0, 0);
            this.pnl_titu.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_titu.Name = "pnl_titu";
            this.pnl_titu.Size = new System.Drawing.Size(1088, 51);
            this.pnl_titu.TabIndex = 1;
            this.pnl_titu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnl_titu_MouseMove);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(617, 9);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 31);
            this.button3.TabIndex = 506;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.button3, "Cancelar Venta");
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(669, 9);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 31);
            this.button2.TabIndex = 505;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.button2, "Reimprimir Documento");
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(720, 9);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 31);
            this.button1.TabIndex = 504;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.button1, "Atender otro Clientes");
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(941, 12);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 26);
            this.label3.TabIndex = 503;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.label3, "Buscar el Cliente");
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuMaterialTextbox1.HintText = "Nro Documento";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.SkyBlue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.SkyBlue;
            this.bunifuMaterialTextbox1.LineThickness = 2;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(785, 4);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(182, 37);
            this.bunifuMaterialTextbox1.TabIndex = 502;
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_minimi
            // 
            this.btn_minimi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minimi.FlatAppearance.BorderSize = 0;
            this.btn_minimi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minimi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_minimi.ForeColor = System.Drawing.Color.White;
            this.btn_minimi.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimi.Image")));
            this.btn_minimi.Location = new System.Drawing.Point(987, 9);
            this.btn_minimi.Margin = new System.Windows.Forms.Padding(4);
            this.btn_minimi.Name = "btn_minimi";
            this.btn_minimi.Size = new System.Drawing.Size(35, 31);
            this.btn_minimi.TabIndex = 7;
            this.btn_minimi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_minimi.UseVisualStyleBackColor = true;
            this.btn_minimi.Click += new System.EventHandler(this.btn_minimi_Click);
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cerrar.FlatAppearance.BorderSize = 0;
            this.btn_cerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cerrar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cerrar.ForeColor = System.Drawing.Color.White;
            this.btn_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("btn_cerrar.Image")));
            this.btn_cerrar.Location = new System.Drawing.Point(1046, 9);
            this.btn_cerrar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(31, 30);
            this.btn_cerrar.TabIndex = 6;
            this.btn_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(4, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ventas con Facturación, Boletas y Otros";
            // 
            // pnl_sinProd
            // 
            this.pnl_sinProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.pnl_sinProd.Controls.Add(this.pnl_subtitu);
            this.pnl_sinProd.Controls.Add(this.chkCapital);
            this.pnl_sinProd.Controls.Add(this.btn_Nuevo_buscarProd);
            this.pnl_sinProd.Controls.Add(this.ElDivider3);
            this.pnl_sinProd.Controls.Add(this.Label17);
            this.pnl_sinProd.Controls.Add(this.PictureBox3);
            this.pnl_sinProd.ForeColor = System.Drawing.Color.Black;
            this.pnl_sinProd.Location = new System.Drawing.Point(0, 49);
            this.pnl_sinProd.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_sinProd.Name = "pnl_sinProd";
            this.pnl_sinProd.Size = new System.Drawing.Size(1088, 578);
            this.pnl_sinProd.TabIndex = 480;
            // 
            // pnl_subtitu
            // 
            this.pnl_subtitu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_subtitu.Location = new System.Drawing.Point(0, 0);
            this.pnl_subtitu.Name = "pnl_subtitu";
            this.pnl_subtitu.Size = new System.Drawing.Size(1088, 36);
            this.pnl_subtitu.TabIndex = 732;            
            // 
            // chkCapital
            // 
            this.chkCapital.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkCapital.AutoSize = true;
            this.chkCapital.Checked = true;
            this.chkCapital.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCapital.Enabled = false;
            this.chkCapital.ForeColor = System.Drawing.Color.White;
            this.chkCapital.Location = new System.Drawing.Point(7, 548);
            this.chkCapital.Name = "chkCapital";
            this.chkCapital.Size = new System.Drawing.Size(112, 23);
            this.chkCapital.TabIndex = 731;
            this.chkCapital.Text = "Letra Capital";
            this.chkCapital.UseVisualStyleBackColor = true;
            // 
            // btn_Nuevo_buscarProd
            // 
            this.btn_Nuevo_buscarProd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientAngle = 0F;
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientEndColor = System.Drawing.Color.OrangeRed;
            this.btn_Nuevo_buscarProd.BackgroundStyle.GradientStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_Nuevo_buscarProd.BackgroundStyle.SolidColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Nuevo_buscarProd.BorderStyle.SolidColor = System.Drawing.Color.DodgerBlue;
            this.btn_Nuevo_buscarProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Nuevo_buscarProd.DropDownArrowColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.EnableThemes = false;
            this.btn_Nuevo_buscarProd.FlashStyle.GradientEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.FlashStyle.GradientStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_Nuevo_buscarProd.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Nuevo_buscarProd.Location = new System.Drawing.Point(416, 330);
            this.btn_Nuevo_buscarProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Nuevo_buscarProd.Name = "btn_Nuevo_buscarProd";
            this.btn_Nuevo_buscarProd.Size = new System.Drawing.Size(258, 59);
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundGradientEndColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundGradientStartColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BackgroundSolidColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderGradientEndColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderGradientStartColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.StateStyles.HoverStyle.BorderSolidColor = System.Drawing.Color.White;
            this.btn_Nuevo_buscarProd.TabIndex = 407;
            this.btn_Nuevo_buscarProd.TextStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Nuevo_buscarProd.TextStyle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nuevo_buscarProd.TextStyle.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btn_Nuevo_buscarProd.TextStyle.Text = "Buscar Productos | Nuevo [F1]";
            this.btn_Nuevo_buscarProd.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Nuevo_buscarProd.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.Custom;
            this.btn_Nuevo_buscarProd.Click += new System.EventHandler(this.btn_Nuevo_buscarProd_Click);
            // 
            // ElDivider3
            // 
            this.ElDivider3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ElDivider3.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.Center;
            this.ElDivider3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ElDivider3.Location = new System.Drawing.Point(24, 258);
            this.ElDivider3.Margin = new System.Windows.Forms.Padding(4);
            this.ElDivider3.Name = "ElDivider3";
            this.ElDivider3.Size = new System.Drawing.Size(1059, 34);
            this.ElDivider3.TabIndex = 408;
            this.ElDivider3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // Label17
            // 
            this.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label17.AutoSize = true;
            this.Label17.BackColor = System.Drawing.Color.Transparent;
            this.Label17.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.ForeColor = System.Drawing.Color.White;
            this.Label17.Location = new System.Drawing.Point(374, 228);
            this.Label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(347, 32);
            this.Label17.TabIndex = 405;
            this.Label17.Text = "Tu carrito de Ventas está Vacio";
            // 
            // PictureBox3
            // 
            this.PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox3.ForeColor = System.Drawing.Color.Black;
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(513, 156);
            this.PictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(68, 68);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PictureBox3.TabIndex = 406;
            this.PictureBox3.TabStop = false;
            // 
            // gru_det
            // 
            this.gru_det.BackgroundStyle.GradientAngle = 45F;
            this.gru_det.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.gru_det.BorderStyle.SolidColor = System.Drawing.Color.SkyBlue;
            this.gru_det.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_det.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.gru_det.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_det.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.gru_det.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.gru_det.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.gru_det.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.Window;
            this.gru_det.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gru_det.CaptionStyle.TextStyle.TextType = Klik.Windows.Forms.v1.Common.TextTypes.BlockShadow;
            this.gru_det.CaptionStyle.Visible = false;
            this.gru_det.CaptionStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.gru_det.Controls.Add(this.bt_Delete);
            this.gru_det.Controls.Add(this.lsv_Det);
            this.gru_det.Controls.Add(this.bt_editPre);
            this.gru_det.Controls.Add(this.bt_add);
            this.gru_det.Controls.Add(this.label9);
            this.gru_det.Controls.Add(this.label8);
            this.gru_det.Controls.Add(this.lbl_TotalItem);
            this.gru_det.Controls.Add(this.label6);
            this.gru_det.Controls.Add(this.label7);
            this.gru_det.Controls.Add(this.label5);
            this.gru_det.Controls.Add(this.elDivider2);
            this.gru_det.Location = new System.Drawing.Point(7, 73);
            this.gru_det.Margin = new System.Windows.Forms.Padding(4);
            this.gru_det.Name = "gru_det";
            this.gru_det.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gru_det.Size = new System.Drawing.Size(824, 280);
            this.gru_det.TabIndex = 2;
            this.gru_det.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // bt_Delete
            // 
            this.bt_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_Delete.FlatAppearance.BorderSize = 0;
            this.bt_Delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_Delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Delete.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Delete.ForeColor = System.Drawing.Color.White;
            this.bt_Delete.Image = ((System.Drawing.Image)(resources.GetObject("bt_Delete.Image")));
            this.bt_Delete.Location = new System.Drawing.Point(790, 130);
            this.bt_Delete.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Delete.Name = "bt_Delete";
            this.bt_Delete.Size = new System.Drawing.Size(26, 26);
            this.bt_Delete.TabIndex = 503;
            this.bt_Delete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_Delete, "Quitar Producto del carrito");
            this.bt_Delete.UseVisualStyleBackColor = true;
            this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
            // 
            // lsv_Det
            // 
            this.lsv_Det.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsv_Det.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lsv_Det.HideSelection = false;
            this.lsv_Det.Location = new System.Drawing.Point(3, 35);
            this.lsv_Det.Name = "lsv_Det";
            this.lsv_Det.Size = new System.Drawing.Size(780, 239);
            this.lsv_Det.TabIndex = 18;
            this.lsv_Det.UseCompatibleStateImageBehavior = false;
            // 
            // bt_editPre
            // 
            this.bt_editPre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_editPre.FlatAppearance.BorderSize = 0;
            this.bt_editPre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editPre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_editPre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_editPre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_editPre.ForeColor = System.Drawing.Color.White;
            this.bt_editPre.Image = ((System.Drawing.Image)(resources.GetObject("bt_editPre.Image")));
            this.bt_editPre.Location = new System.Drawing.Point(790, 83);
            this.bt_editPre.Margin = new System.Windows.Forms.Padding(4);
            this.bt_editPre.Name = "bt_editPre";
            this.bt_editPre.Size = new System.Drawing.Size(26, 26);
            this.bt_editPre.TabIndex = 501;
            this.bt_editPre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_editPre, "Editar Precio ");
            this.bt_editPre.UseVisualStyleBackColor = true;
            this.bt_editPre.Click += new System.EventHandler(this.bt_editPre_Click);
            // 
            // bt_add
            // 
            this.bt_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_add.FlatAppearance.BorderSize = 0;
            this.bt_add.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.bt_add.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.bt_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_add.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_add.ForeColor = System.Drawing.Color.White;
            this.bt_add.Image = ((System.Drawing.Image)(resources.GetObject("bt_add.Image")));
            this.bt_add.Location = new System.Drawing.Point(790, 38);
            this.bt_add.Margin = new System.Windows.Forms.Padding(4);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(26, 26);
            this.bt_add.TabIndex = 500;
            this.bt_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bt_add, "Agregar mas Productos [F4]");
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(460, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 23);
            this.label9.TabIndex = 12;
            this.label9.Text = "Cant.";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(633, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 23);
            this.label8.TabIndex = 11;
            this.label8.Text = "Importe";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_TotalItem
            // 
            this.lbl_TotalItem.AutoSize = true;
            this.lbl_TotalItem.Font = new System.Drawing.Font("Oxygen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalItem.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_TotalItem.Location = new System.Drawing.Point(789, 179);
            this.lbl_TotalItem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TotalItem.Name = "lbl_TotalItem";
            this.lbl_TotalItem.Size = new System.Drawing.Size(27, 19);
            this.lbl_TotalItem.TabIndex = 499;
            this.lbl_TotalItem.Text = "00";
            this.lbl_TotalItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.lbl_TotalItem, "Total de Items");
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(542, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 23);
            this.label6.TabIndex = 10;
            this.label6.Text = "Pre Unit.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(85, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(377, 23);
            this.label7.TabIndex = 9;
            this.label7.Text = "Descripcion del Producto";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(5, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Id Prod.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // elDivider2
            // 
            this.elDivider2.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.None;
            this.elDivider2.Location = new System.Drawing.Point(0, 27);
            this.elDivider2.Name = "elDivider2";
            this.elDivider2.Size = new System.Drawing.Size(783, 10);
            this.elDivider2.TabIndex = 513;
            this.elDivider2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btn_procesar
            // 
            this.btn_procesar.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_procesar.BackgroundStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.btn_procesar.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.btn_procesar.BorderStyle.EdgeRadius = 7;
            this.btn_procesar.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.btn_procesar.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            this.btn_procesar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_procesar.DropDownArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.btn_procesar.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btn_procesar.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btn_procesar.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_procesar.Location = new System.Drawing.Point(20, 467);
            this.btn_procesar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_procesar.Name = "btn_procesar";
            this.btn_procesar.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernBlack;
            this.btn_procesar.Size = new System.Drawing.Size(199, 54);
            this.btn_procesar.StateStyles.HoverStyle.BackgroundSolidColor = System.Drawing.Color.YellowGreen;
            this.btn_procesar.StateStyles.HoverStyle.BorderSolidColor = System.Drawing.Color.YellowGreen;
            this.btn_procesar.TabIndex = 6;
            this.btn_procesar.TextStyle.Font = new System.Drawing.Font("Oxygen", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_procesar.TextStyle.ForeColor = System.Drawing.Color.White;
            this.btn_procesar.TextStyle.Text = "Procesar Venta (F5)";
            this.btn_procesar.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_procesar.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.Custom;
            
            // 
            // txt_NroCotiza
            // 
            this.txt_NroCotiza.Location = new System.Drawing.Point(430, 150);
            this.txt_NroCotiza.Name = "txt_NroCotiza";
            this.txt_NroCotiza.Size = new System.Drawing.Size(140, 26);
            this.txt_NroCotiza.TabIndex = 484;
            this.txt_NroCotiza.Visible = false;
            // 
            // gru_numeros
            // 
            this.gru_numeros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gru_numeros.BackgroundStyle.GradientAngle = 45F;
            this.gru_numeros.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_numeros.BackgroundStyle.SolidColor = System.Drawing.Color.WhiteSmoke;
            this.gru_numeros.BorderStyle.SolidColor = System.Drawing.Color.SkyBlue;
            this.gru_numeros.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_numeros.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.gru_numeros.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_numeros.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_numeros.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_numeros.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.gru_numeros.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.gru_numeros.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.gru_numeros.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.gru_numeros.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.gru_numeros.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.gru_numeros.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.Window;
            this.gru_numeros.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gru_numeros.CaptionStyle.TextStyle.TextType = Klik.Windows.Forms.v1.Common.TextTypes.BlockShadow;
            this.gru_numeros.CaptionStyle.Visible = false;
            this.gru_numeros.CaptionStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.gru_numeros.Controls.Add(this.label26);
            this.gru_numeros.Controls.Add(this.label27);
            this.gru_numeros.Controls.Add(this.label24);
            this.gru_numeros.Controls.Add(this.label25);
            this.gru_numeros.Controls.Add(this.elDivider5);
            this.gru_numeros.Controls.Add(this.label2);
            this.gru_numeros.Controls.Add(this.label10);
            this.gru_numeros.Controls.Add(this.elDivider1);
            this.gru_numeros.Controls.Add(this.lbl_totalGanancia);
            this.gru_numeros.Controls.Add(this.lbl_Frank);
            this.gru_numeros.Controls.Add(this.bunifuSeparator9);
            this.gru_numeros.Controls.Add(this.bunifuSeparator8);
            this.gru_numeros.Controls.Add(this.label23);
            this.gru_numeros.Controls.Add(this.lbl_igv);
            this.gru_numeros.Controls.Add(this.label21);
            this.gru_numeros.Controls.Add(this.lbl_subtotal);
            this.gru_numeros.Controls.Add(this.label18);
            this.gru_numeros.Controls.Add(this.label16);
            this.gru_numeros.Controls.Add(this.btn_procesar);
            this.gru_numeros.Controls.Add(this.elDivider4);
            this.gru_numeros.Controls.Add(this.lbl_TotalPagar);
            this.gru_numeros.Location = new System.Drawing.Point(856, 72);
            this.gru_numeros.Margin = new System.Windows.Forms.Padding(4);
            this.gru_numeros.Name = "gru_numeros";
            this.gru_numeros.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gru_numeros.Size = new System.Drawing.Size(231, 545);
            this.gru_numeros.TabIndex = 485;
            this.gru_numeros.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(16, 384);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(85, 19);
            this.label26.TabIndex = 522;
            this.label26.Text = "Saldo Vale:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Tomato;
            this.label27.Location = new System.Drawing.Point(126, 380);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(93, 27);
            this.label27.TabIndex = 521;
            this.label27.Text = "00.00";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(16, 350);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 19);
            this.label24.TabIndex = 520;
            this.label24.Text = "Saldo Pndte.";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Tomato;
            this.label25.Location = new System.Drawing.Point(126, 347);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 27);
            this.label25.TabIndex = 519;
            this.label25.Text = "00.00";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // elDivider5
            // 
            this.elDivider5.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.None;
            this.elDivider5.LineSize = 1;
            this.elDivider5.Location = new System.Drawing.Point(40, 334);
            this.elDivider5.Name = "elDivider5";
            this.elDivider5.Size = new System.Drawing.Size(171, 10);
            this.elDivider5.TabIndex = 518;
            this.elDivider5.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(79, 311);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 517;
            this.label2.Text = "Otros Datos";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 418);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 19);
            this.label10.TabIndex = 516;
            this.label10.Text = "Ganancias:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // elDivider1
            // 
            this.elDivider1.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.None;
            this.elDivider1.Location = new System.Drawing.Point(36, 30);
            this.elDivider1.Name = "elDivider1";
            this.elDivider1.Size = new System.Drawing.Size(171, 16);
            this.elDivider1.TabIndex = 513;
            this.elDivider1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lbl_totalGanancia
            // 
            this.lbl_totalGanancia.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalGanancia.ForeColor = System.Drawing.Color.Tomato;
            this.lbl_totalGanancia.Location = new System.Drawing.Point(129, 414);
            this.lbl_totalGanancia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_totalGanancia.Name = "lbl_totalGanancia";
            this.lbl_totalGanancia.Size = new System.Drawing.Size(93, 27);
            this.lbl_totalGanancia.TabIndex = 504;
            this.lbl_totalGanancia.Text = "00.00";
            this.lbl_totalGanancia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_Frank
            // 
            this.lbl_Frank.AutoSize = true;
            this.lbl_Frank.Location = new System.Drawing.Point(14, 526);
            this.lbl_Frank.Name = "lbl_Frank";
            this.lbl_Frank.Size = new System.Drawing.Size(18, 19);
            this.lbl_Frank.TabIndex = 500;
            this.lbl_Frank.Text = "0";
            // 
            // bunifuSeparator9
            // 
            this.bunifuSeparator9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator9.LineThickness = 1;
            this.bunifuSeparator9.Location = new System.Drawing.Point(36, 208);
            this.bunifuSeparator9.Margin = new System.Windows.Forms.Padding(9);
            this.bunifuSeparator9.Name = "bunifuSeparator9";
            this.bunifuSeparator9.Size = new System.Drawing.Size(196, 13);
            this.bunifuSeparator9.TabIndex = 501;
            this.bunifuSeparator9.Transparency = 255;
            this.bunifuSeparator9.Vertical = false;
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(36, 129);
            this.bunifuSeparator8.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(196, 17);
            this.bunifuSeparator8.TabIndex = 500;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Tomato;
            this.label23.Font = new System.Drawing.Font("Oxygen", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label23.Location = new System.Drawing.Point(4, 234);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 16);
            this.label23.TabIndex = 495;
            this.label23.Text = "Total S/.";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_igv
            // 
            this.lbl_igv.Font = new System.Drawing.Font("Oxygen", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_igv.ForeColor = System.Drawing.Color.Black;
            this.lbl_igv.Location = new System.Drawing.Point(51, 174);
            this.lbl_igv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_igv.Name = "lbl_igv";
            this.lbl_igv.Size = new System.Drawing.Size(126, 27);
            this.lbl_igv.TabIndex = 494;
            this.lbl_igv.Text = "00.00";
            this.lbl_igv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.DimGray;
            this.label21.Location = new System.Drawing.Point(126, 146);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 19);
            this.label21.TabIndex = 493;
            this.label21.Text = "Igv S/";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.Font = new System.Drawing.Font("Oxygen", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtotal.ForeColor = System.Drawing.Color.Black;
            this.lbl_subtotal.Location = new System.Drawing.Point(50, 101);
            this.lbl_subtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(126, 27);
            this.lbl_subtotal.TabIndex = 492;
            this.lbl_subtotal.Text = "00.00";
            this.lbl_subtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.DimGray;
            this.label18.Location = new System.Drawing.Point(79, 75);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(97, 19);
            this.label18.TabIndex = 490;
            this.label18.Text = "Sub Total S/.";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Oxygen", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.label16.Location = new System.Drawing.Point(75, 3);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 24);
            this.label16.TabIndex = 484;
            this.label16.Text = "Importes ";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // elDivider4
            // 
            this.elDivider4.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.Center;
            this.elDivider4.LineSize = 3;
            this.elDivider4.Location = new System.Drawing.Point(38, 517);
            this.elDivider4.Name = "elDivider4";
            this.elDivider4.Size = new System.Drawing.Size(171, 16);
            this.elDivider4.TabIndex = 514;
            // 
            // lbl_TotalPagar
            // 
            this.lbl_TotalPagar.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_TotalPagar.BackgroundStyle.SolidColor = System.Drawing.Color.Tomato;
            this.lbl_TotalPagar.BorderStyle.SolidColor = System.Drawing.Color.Tomato;
            paintStyle6.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle6.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_TotalPagar.FlashStyle = paintStyle6;
            this.lbl_TotalPagar.Location = new System.Drawing.Point(0, 232);
            this.lbl_TotalPagar.Name = "lbl_TotalPagar";
            this.lbl_TotalPagar.Size = new System.Drawing.Size(232, 50);
            this.lbl_TotalPagar.TabIndex = 514;
            this.lbl_TotalPagar.TabStop = false;
            this.lbl_TotalPagar.TextStyle.Font = new System.Drawing.Font("Oxygen", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPagar.TextStyle.ForeColor = System.Drawing.Color.White;
            this.lbl_TotalPagar.TextStyle.Text = "150.20";
            this.lbl_TotalPagar.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_TotalPagar.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Location = new System.Drawing.Point(0, 624);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1088, 3);
            this.label4.TabIndex = 486;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dtp_FechaEmi
            // 
            this.dtp_FechaEmi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaEmi.Location = new System.Drawing.Point(138, 150);
            this.dtp_FechaEmi.Name = "dtp_FechaEmi";
            this.dtp_FechaEmi.Size = new System.Drawing.Size(140, 26);
            this.dtp_FechaEmi.TabIndex = 490;
            this.dtp_FechaEmi.Visible = false;
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // lbl_BusClien
            // 
            this.lbl_BusClien.Image = ((System.Drawing.Image)(resources.GetObject("lbl_BusClien.Image")));
            this.lbl_BusClien.Location = new System.Drawing.Point(6, 14);
            this.lbl_BusClien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_BusClien.Name = "lbl_BusClien";
            this.lbl_BusClien.Size = new System.Drawing.Size(26, 26);
            this.lbl_BusClien.TabIndex = 502;
            this.lbl_BusClien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.lbl_BusClien, "Buscar el Cliente");
            this.lbl_BusClien.Click += new System.EventHandler(this.lbl_BusClien_Click);
            // 
            // label14
            // 
            this.label14.Image = ((System.Drawing.Image)(resources.GetObject("label14.Image")));
            this.label14.Location = new System.Drawing.Point(4, 55);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 26);
            this.label14.TabIndex = 517;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.label14, "Direccion del cliente");
            // 
            // label19
            // 
            this.label19.Image = ((System.Drawing.Image)(resources.GetObject("label19.Image")));
            this.label19.Location = new System.Drawing.Point(4, 102);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 26);
            this.label19.TabIndex = 518;
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.label19, "Nro de RUC o DNI");
            // 
            // label28
            // 
            this.label28.Image = ((System.Drawing.Image)(resources.GetObject("label28.Image")));
            this.label28.Location = new System.Drawing.Point(514, 57);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 26);
            this.label28.TabIndex = 519;
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.label28, "Tipo de Pago");
            // 
            // label29
            // 
            this.label29.Image = ((System.Drawing.Image)(resources.GetObject("label29.Image")));
            this.label29.Location = new System.Drawing.Point(513, 104);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 26);
            this.label29.TabIndex = 522;
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.label29, "Tipo de Documento a Emitir");
            // 
            // lbl_son
            // 
            this.lbl_son.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_son.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_son.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.lbl_son.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.lbl_son.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle5.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle5.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_son.FlashStyle = paintStyle5;
            this.lbl_son.Location = new System.Drawing.Point(7, 353);
            this.lbl_son.Name = "lbl_son";
            this.lbl_son.Size = new System.Drawing.Size(824, 30);
            this.lbl_son.TabIndex = 500;
            this.lbl_son.TabStop = false;
            this.lbl_son.TextStyle.Font = new System.Drawing.Font("Oxygen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_son.TextStyle.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_son.TextStyle.Text = "Son 00/100 Soles";
            this.lbl_son.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txt_cliente
            // 
            this.txt_cliente.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_cliente.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_cliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_cliente.HintForeColor = System.Drawing.Color.LightSlateGray;
            this.txt_cliente.HintText = "Buscar Cliente";
            this.txt_cliente.isPassword = false;
            this.txt_cliente.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_cliente.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_cliente.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_cliente.LineThickness = 2;
            this.txt_cliente.Location = new System.Drawing.Point(36, 13);
            this.txt_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(422, 33);
            this.txt_cliente.TabIndex = 501;
            this.txt_cliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_cliente.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_cliente_KeyDown);
            // 
            // txt_nroPed
            // 
            this.txt_nroPed.Location = new System.Drawing.Point(284, 150);
            this.txt_nroPed.Name = "txt_nroPed";
            this.txt_nroPed.Size = new System.Drawing.Size(140, 26);
            this.txt_nroPed.TabIndex = 510;
            this.txt_nroPed.Visible = false;
            // 
            // lbl_idcliente
            // 
            this.lbl_idcliente.AutoSize = true;
            this.lbl_idcliente.ForeColor = System.Drawing.Color.Gray;
            this.lbl_idcliente.Location = new System.Drawing.Point(216, 106);
            this.lbl_idcliente.Name = "lbl_idcliente";
            this.lbl_idcliente.Size = new System.Drawing.Size(18, 19);
            this.lbl_idcliente.TabIndex = 513;
            this.lbl_idcliente.Text = "0";
            // 
            // elGroupBox1
            // 
            this.elGroupBox1.BackgroundStyle.GradientAngle = 45F;
            this.elGroupBox1.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.elGroupBox1.BorderStyle.SolidColor = System.Drawing.Color.SkyBlue;
            this.elGroupBox1.CaptionStyle.Align = System.Drawing.ContentAlignment.TopLeft;
            this.elGroupBox1.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox1.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.elGroupBox1.CaptionStyle.BorderStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(151)))), ((int)(((byte)(191)))));
            this.elGroupBox1.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox1.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elGroupBox1.CaptionStyle.ForegroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.elGroupBox1.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elGroupBox1.CaptionStyle.Size = new System.Drawing.Size(40, 40);
            this.elGroupBox1.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.elGroupBox1.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Lato", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elGroupBox1.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.elGroupBox1.CaptionStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elGroupBox1.Controls.Add(this.panel1);
            this.elGroupBox1.Location = new System.Drawing.Point(7, 390);
            this.elGroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.elGroupBox1.Name = "elGroupBox1";
            this.elGroupBox1.Padding = new System.Windows.Forms.Padding(4, 43, 4, 3);
            this.elGroupBox1.Size = new System.Drawing.Size(824, 228);
            this.elGroupBox1.TabIndex = 514;
            this.elGroupBox1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.elLabel4);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.elLabel3);
            this.panel1.Controls.Add(this.lbl_idcliente);
            this.panel1.Controls.Add(this.txt_nroPed);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.elLabel2);
            this.panel1.Controls.Add(this.elLabel1);
            this.panel1.Controls.Add(this.txt_cliente);
            this.panel1.Controls.Add(this.lbl_BusClien);
            this.panel1.Controls.Add(this.dtp_FechaEmi);
            this.panel1.Controls.Add(this.txt_NroCotiza);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(816, 182);
            this.panel1.TabIndex = 515;
            // 
            // comboBox2
            // 
            this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox2.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Nota Venta",
            "Factura",
            "Boleta"});
            this.comboBox2.Location = new System.Drawing.Point(545, 103);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(174, 27);
            this.comboBox2.TabIndex = 521;
            // 
            // elLabel4
            // 
            this.elLabel4.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elLabel4.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.elLabel4.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            this.elLabel4.Cursor = System.Windows.Forms.Cursors.Default;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel4.FlashStyle = paintStyle1;
            this.elLabel4.Location = new System.Drawing.Point(543, 101);
            this.elLabel4.Name = "elLabel4";
            this.elLabel4.Size = new System.Drawing.Size(180, 32);
            this.elLabel4.TabIndex = 520;
            this.elLabel4.TabStop = false;
            this.elLabel4.TextStyle.Font = new System.Drawing.Font("Oxygen", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel4.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elLabel4.TextStyle.Text = "150.20";
            this.elLabel4.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elLabel4.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // comboBox1
            // 
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Efectivo",
            "Deposito",
            "Credito",
            "Vale"});
            this.comboBox1.Location = new System.Drawing.Point(545, 56);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(174, 27);
            this.comboBox1.TabIndex = 518;
            // 
            // elLabel3
            // 
            this.elLabel3.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elLabel3.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.elLabel3.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            this.elLabel3.Cursor = System.Windows.Forms.Cursors.Default;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel3.FlashStyle = paintStyle2;
            this.elLabel3.Location = new System.Drawing.Point(543, 54);
            this.elLabel3.Name = "elLabel3";
            this.elLabel3.Size = new System.Drawing.Size(180, 32);
            this.elLabel3.TabIndex = 517;
            this.elLabel3.TabStop = false;
            this.elLabel3.TextStyle.Font = new System.Drawing.Font("Oxygen", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel3.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elLabel3.TextStyle.Text = "150.20";
            this.elLabel3.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elLabel3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elLabel2
            // 
            this.elLabel2.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elLabel2.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.elLabel2.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle3.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle3.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel2.FlashStyle = paintStyle3;
            this.elLabel2.Location = new System.Drawing.Point(36, 100);
            this.elLabel2.Name = "elLabel2";
            this.elLabel2.Size = new System.Drawing.Size(174, 32);
            this.elLabel2.TabIndex = 516;
            this.elLabel2.TabStop = false;
            this.elLabel2.TextStyle.Font = new System.Drawing.Font("Oxygen", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel2.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elLabel2.TextStyle.Text = "150.20";
            this.elLabel2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elLabel2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elLabel1
            // 
            this.elLabel1.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elLabel1.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.elLabel1.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle4.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle4.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel1.FlashStyle = paintStyle4;
            this.elLabel1.Location = new System.Drawing.Point(36, 55);
            this.elLabel1.Name = "elLabel1";
            this.elLabel1.Size = new System.Drawing.Size(422, 32);
            this.elLabel1.TabIndex = 515;
            this.elLabel1.TabStop = false;
            this.elLabel1.TextStyle.Font = new System.Drawing.Font("Oxygen", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel1.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elLabel1.TextStyle.Text = "150.20";
            this.elLabel1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elLabel1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // Frm_Crear_Ventas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1088, 627);
            this.Controls.Add(this.pnl_sinProd);
            this.Controls.Add(this.elGroupBox1);
            this.Controls.Add(this.lbl_son);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gru_numeros);
            this.Controls.Add(this.gru_det);
            this.Controls.Add(this.pnl_titu);
            this.Font = new System.Drawing.Font("Oxygen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Crear_Ventas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Frm_Ventana_Ventas_Load);            
            this.pnl_titu.ResumeLayout(false);
            this.pnl_titu.PerformLayout();
            this.pnl_sinProd.ResumeLayout(false);
            this.pnl_sinProd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Nuevo_buscarProd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElDivider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gru_det)).EndInit();
            this.gru_det.ResumeLayout(false);
            this.gru_det.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_procesar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gru_numeros)).EndInit();
            this.gru_numeros.ResumeLayout(false);
            this.gru_numeros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_TotalPagar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_son)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox1)).EndInit();
            this.elGroupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel pnl_titu;
        private System.Windows.Forms.Button btn_minimi;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.Label label1;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox gru_det;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btn_procesar;
        internal System.Windows.Forms.Panel pnl_sinProd;
        internal Klik.Windows.Forms.v1.EntryLib.ELButton btn_Nuevo_buscarProd;
        internal Klik.Windows.Forms.v1.EntryLib.ELDivider ElDivider3;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.PictureBox PictureBox3;
        private System.Windows.Forms.TextBox txt_NroCotiza;
        private System.Windows.Forms.Label label4;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox gru_numeros;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListView lsv_Det;
        private System.Windows.Forms.DateTimePicker dtp_FechaEmi;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_igv;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button bt_Delete;
        private System.Windows.Forms.Button bt_editPre;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lbl_Frank;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator9;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator8;
        private System.Windows.Forms.Label lbl_TotalItem;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_son;
        private System.Windows.Forms.Label lbl_BusClien;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_cliente;
        private System.Windows.Forms.TextBox txt_nroPed;
        private System.Windows.Forms.CheckBox chkCapital;
        private System.Windows.Forms.Label lbl_totalGanancia;
        private System.Windows.Forms.Panel pnl_subtitu;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider1;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider2;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider4;
        private System.Windows.Forms.Label lbl_idcliente;
        private System.Windows.Forms.Label label10;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_TotalPagar;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox elGroupBox1;
        private System.Windows.Forms.Panel panel1;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel2;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel1;
        private System.Windows.Forms.ComboBox comboBox2;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox1;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
    }
}