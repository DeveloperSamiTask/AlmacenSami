﻿namespace Microsell_Lite
{
    partial class Frm_Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Principal));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Pnl_Menu = new System.Windows.Forms.Panel();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bt_MenuPrinci = new System.Windows.Forms.ToolStripMenuItem();
            this.SeccionComprasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_RegistrarUnaCompra = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_EliminarFacturaCompra = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.ConsultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_AbrirExploradorDeCompras = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_AbrirExploradorDeProveedores = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.VerComprasACreditoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.SeccionCajaSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_AperturarCajaDelDia = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_RegistrarGastos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_RegistrarOtrosIngresos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ConsultasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_VerMovimientoDeCaja = new System.Windows.Forms.ToolStripMenuItem();
            this.SeccionVentasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_VentanaDeFacturación = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_crearUnaCotización = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_CajearUnaNotaVenta = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_CanjearUnaNotaVenta = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_CanjearVariasNotas = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator38 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_DuplicarUnaNota = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.ConsultasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_VerDocumentosEmitidos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_VerCotizacionesEmitidas = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_VerCreditoDeClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator44 = new System.Windows.Forms.ToolStripSeparator();
            this.bt_VerListadoDeClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.AdministraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_DevolverProductoConVale = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_EditarUnaVenta = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_ConvertirVentaACredito = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_HacerCierreDeCaja = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_RegistrarUsuarios = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.ConsultasToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_VerCierreDeCaja = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.SeccionAlmacenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.ConsultasToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.bt_VerExploradorDeProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.bt_VerMovimientoDeProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_ReporteDeProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.MantenimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_LimpiarTemporalesDeGuia = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_LimpiarTemporalesDeVenta = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_MantenimientoCategoria = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_MantenimientoMarca = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_Config = new System.Windows.Forms.ToolStripMenuItem();
            this.Bt_RegistrarMiEmpresa = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_EditarCorrelativos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_RestringirAcceso = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_EditarTipoDeCambio = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripSeparator41 = new System.Windows.Forms.ToolStripSeparator();
            this.Bt_Configu = new System.Windows.Forms.ToolStripMenuItem();
            this.GfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bt_salidadinero = new System.Windows.Forms.ToolStripMenuItem();
            this.LiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bt_EntradaDinero = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_minimi = new System.Windows.Forms.Button();
            this.PicLogo = new System.Windows.Forms.PictureBox();
            this.PanelLateral = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PicUser_2 = new System.Windows.Forms.PictureBox();
            this.bt_DocEmitidos = new System.Windows.Forms.Button();
            this.bt_cliente = new System.Windows.Forms.Button();
            this.bt_almacen = new System.Windows.Forms.Button();
            this.Bt_cotizar = new System.Windows.Forms.Button();
            this.Bt_ventas = new System.Windows.Forms.Button();
            this.btn_hide = new System.Windows.Forms.Button();
            this.bt_compras = new System.Windows.Forms.Button();
            this.Dtp_FechaHoy = new System.Windows.Forms.DateTimePicker();
            this.lbl_miperfil = new System.Windows.Forms.Label();
            this.lbl_Rol = new System.Windows.Forms.Label();
            this.lbl_user = new System.Windows.Forms.Label();
            this.PicUser = new System.Windows.Forms.PictureBox();
            this.Pnl_Menu.SuspendLayout();
            this.MenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicLogo)).BeginInit();
            this.PanelLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 10;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Pnl_Menu
            // 
            this.Pnl_Menu.BackColor = System.Drawing.Color.Gray;
            this.Pnl_Menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pnl_Menu.Controls.Add(this.btn_cerrar);
            this.Pnl_Menu.Controls.Add(this.MenuStrip1);
            this.Pnl_Menu.Controls.Add(this.btn_minimi);
            this.Pnl_Menu.Controls.Add(this.PicLogo);
            this.Pnl_Menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_Menu.Location = new System.Drawing.Point(0, 0);
            this.Pnl_Menu.Name = "Pnl_Menu";
            this.Pnl_Menu.Size = new System.Drawing.Size(1344, 55);
            this.Pnl_Menu.TabIndex = 2;
            this.Pnl_Menu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Pnl_Menu_MouseMove);
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cerrar.FlatAppearance.BorderSize = 0;
            this.btn_cerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cerrar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cerrar.ForeColor = System.Drawing.Color.White;
            this.btn_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("btn_cerrar.Image")));
            this.btn_cerrar.Location = new System.Drawing.Point(1301, 10);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(32, 32);
            this.btn_cerrar.TabIndex = 5;
            this.btn_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bt_MenuPrinci,
            this.Bt_Config,
            this.Bt_Configu,
            this.GfToolStripMenuItem,
            this.bt_salidadinero,
            this.LiToolStripMenuItem,
            this.bt_EntradaDinero});
            this.MenuStrip1.Location = new System.Drawing.Point(186, 14);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.ShowItemToolTips = true;
            this.MenuStrip1.Size = new System.Drawing.Size(286, 32);
            this.MenuStrip1.TabIndex = 7;
            // 
            // bt_MenuPrinci
            // 
            this.bt_MenuPrinci.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SeccionComprasToolStripMenuItem1,
            this.ToolStripSeparator10,
            this.SeccionCajaSToolStripMenuItem,
            this.SeccionVentasToolStripMenuItem1,
            this.ToolStripSeparator11,
            this.AdministraciónToolStripMenuItem,
            this.ToolStripSeparator13,
            this.SeccionAlmacenToolStripMenuItem1,
            this.ToolStripSeparator15,
            this.MantenimientoToolStripMenuItem});
            this.bt_MenuPrinci.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_MenuPrinci.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bt_MenuPrinci.Image = ((System.Drawing.Image)(resources.GetObject("bt_MenuPrinci.Image")));
            this.bt_MenuPrinci.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.bt_MenuPrinci.Name = "bt_MenuPrinci";
            this.bt_MenuPrinci.Size = new System.Drawing.Size(82, 28);
            this.bt_MenuPrinci.Text = "Menu";
            this.bt_MenuPrinci.ToolTipText = "Menu Principal";
            // 
            // SeccionComprasToolStripMenuItem1
            // 
            this.SeccionComprasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_RegistrarUnaCompra,
            this.ToolStripSeparator16,
            this.Bt_EliminarFacturaCompra,
            this.ToolStripSeparator17,
            this.ConsultasToolStripMenuItem,
            this.Bt_AbrirExploradorDeCompras,
            this.toolStripSeparator5,
            this.Bt_AbrirExploradorDeProveedores,
            this.toolStripSeparator6,
            this.VerComprasACreditoToolStripMenuItem});
            this.SeccionComprasToolStripMenuItem1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeccionComprasToolStripMenuItem1.ForeColor = System.Drawing.Color.DimGray;
            this.SeccionComprasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("SeccionComprasToolStripMenuItem1.Image")));
            this.SeccionComprasToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SeccionComprasToolStripMenuItem1.Name = "SeccionComprasToolStripMenuItem1";
            this.SeccionComprasToolStripMenuItem1.Size = new System.Drawing.Size(214, 30);
            this.SeccionComprasToolStripMenuItem1.Text = "Seccion Compras";
            // 
            // Bt_RegistrarUnaCompra
            // 
            this.Bt_RegistrarUnaCompra.Enabled = false;
            this.Bt_RegistrarUnaCompra.Image = ((System.Drawing.Image)(resources.GetObject("Bt_RegistrarUnaCompra.Image")));
            this.Bt_RegistrarUnaCompra.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_RegistrarUnaCompra.Name = "Bt_RegistrarUnaCompra";
            this.Bt_RegistrarUnaCompra.Size = new System.Drawing.Size(321, 26);
            this.Bt_RegistrarUnaCompra.Text = "Registrar una Compra";
            // 
            // ToolStripSeparator16
            // 
            this.ToolStripSeparator16.Name = "ToolStripSeparator16";
            this.ToolStripSeparator16.Size = new System.Drawing.Size(318, 6);
            // 
            // Bt_EliminarFacturaCompra
            // 
            this.Bt_EliminarFacturaCompra.Enabled = false;
            this.Bt_EliminarFacturaCompra.Image = ((System.Drawing.Image)(resources.GetObject("Bt_EliminarFacturaCompra.Image")));
            this.Bt_EliminarFacturaCompra.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_EliminarFacturaCompra.Name = "Bt_EliminarFacturaCompra";
            this.Bt_EliminarFacturaCompra.Size = new System.Drawing.Size(321, 26);
            this.Bt_EliminarFacturaCompra.Text = "Eliminar Factura Compra";
            // 
            // ToolStripSeparator17
            // 
            this.ToolStripSeparator17.Name = "ToolStripSeparator17";
            this.ToolStripSeparator17.Size = new System.Drawing.Size(318, 6);
            // 
            // ConsultasToolStripMenuItem
            // 
            this.ConsultasToolStripMenuItem.Enabled = false;
            this.ConsultasToolStripMenuItem.Name = "ConsultasToolStripMenuItem";
            this.ConsultasToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.ConsultasToolStripMenuItem.Text = "========Consultas=========";
            // 
            // Bt_AbrirExploradorDeCompras
            // 
            this.Bt_AbrirExploradorDeCompras.Enabled = false;
            this.Bt_AbrirExploradorDeCompras.Name = "Bt_AbrirExploradorDeCompras";
            this.Bt_AbrirExploradorDeCompras.Size = new System.Drawing.Size(321, 26);
            this.Bt_AbrirExploradorDeCompras.Text = "Abrir Explorador de Compras";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(318, 6);
            // 
            // Bt_AbrirExploradorDeProveedores
            // 
            this.Bt_AbrirExploradorDeProveedores.Enabled = false;
            this.Bt_AbrirExploradorDeProveedores.Name = "Bt_AbrirExploradorDeProveedores";
            this.Bt_AbrirExploradorDeProveedores.Size = new System.Drawing.Size(321, 26);
            this.Bt_AbrirExploradorDeProveedores.Text = "Abrir Explorador de Proveedores";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(318, 6);
            // 
            // VerComprasACreditoToolStripMenuItem
            // 
            this.VerComprasACreditoToolStripMenuItem.Enabled = false;
            this.VerComprasACreditoToolStripMenuItem.Name = "VerComprasACreditoToolStripMenuItem";
            this.VerComprasACreditoToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.VerComprasACreditoToolStripMenuItem.Text = "Ver Compras a Credito";
            // 
            // ToolStripSeparator10
            // 
            this.ToolStripSeparator10.Name = "ToolStripSeparator10";
            this.ToolStripSeparator10.Size = new System.Drawing.Size(211, 6);
            // 
            // SeccionCajaSToolStripMenuItem
            // 
            this.SeccionCajaSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_AperturarCajaDelDia,
            this.ToolStripSeparator23,
            this.Bt_RegistrarGastos,
            this.ToolStripSeparator24,
            this.Bt_RegistrarOtrosIngresos,
            this.ToolStripSeparator3,
            this.ConsultasToolStripMenuItem2,
            this.Bt_VerMovimientoDeCaja});
            this.SeccionCajaSToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeccionCajaSToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.SeccionCajaSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("SeccionCajaSToolStripMenuItem.Image")));
            this.SeccionCajaSToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SeccionCajaSToolStripMenuItem.Name = "SeccionCajaSToolStripMenuItem";
            this.SeccionCajaSToolStripMenuItem.Size = new System.Drawing.Size(214, 30);
            this.SeccionCajaSToolStripMenuItem.Text = "Seccion de Caja";
            // 
            // Bt_AperturarCajaDelDia
            // 
            this.Bt_AperturarCajaDelDia.Enabled = false;
            this.Bt_AperturarCajaDelDia.Image = ((System.Drawing.Image)(resources.GetObject("Bt_AperturarCajaDelDia.Image")));
            this.Bt_AperturarCajaDelDia.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_AperturarCajaDelDia.Name = "Bt_AperturarCajaDelDia";
            this.Bt_AperturarCajaDelDia.Size = new System.Drawing.Size(263, 26);
            this.Bt_AperturarCajaDelDia.Text = "Aperturar Caja del Dia";
            // 
            // ToolStripSeparator23
            // 
            this.ToolStripSeparator23.Name = "ToolStripSeparator23";
            this.ToolStripSeparator23.Size = new System.Drawing.Size(260, 6);
            // 
            // Bt_RegistrarGastos
            // 
            this.Bt_RegistrarGastos.Enabled = false;
            this.Bt_RegistrarGastos.Image = ((System.Drawing.Image)(resources.GetObject("Bt_RegistrarGastos.Image")));
            this.Bt_RegistrarGastos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_RegistrarGastos.Name = "Bt_RegistrarGastos";
            this.Bt_RegistrarGastos.Size = new System.Drawing.Size(263, 26);
            this.Bt_RegistrarGastos.Text = "Registrar Gastos";
            // 
            // ToolStripSeparator24
            // 
            this.ToolStripSeparator24.Name = "ToolStripSeparator24";
            this.ToolStripSeparator24.Size = new System.Drawing.Size(260, 6);
            // 
            // Bt_RegistrarOtrosIngresos
            // 
            this.Bt_RegistrarOtrosIngresos.Enabled = false;
            this.Bt_RegistrarOtrosIngresos.Image = ((System.Drawing.Image)(resources.GetObject("Bt_RegistrarOtrosIngresos.Image")));
            this.Bt_RegistrarOtrosIngresos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_RegistrarOtrosIngresos.Name = "Bt_RegistrarOtrosIngresos";
            this.Bt_RegistrarOtrosIngresos.Size = new System.Drawing.Size(263, 26);
            this.Bt_RegistrarOtrosIngresos.Text = "Registrar Otros Ingresos";
            // 
            // ToolStripSeparator3
            // 
            this.ToolStripSeparator3.Name = "ToolStripSeparator3";
            this.ToolStripSeparator3.Size = new System.Drawing.Size(260, 6);
            // 
            // ConsultasToolStripMenuItem2
            // 
            this.ConsultasToolStripMenuItem2.Enabled = false;
            this.ConsultasToolStripMenuItem2.Name = "ConsultasToolStripMenuItem2";
            this.ConsultasToolStripMenuItem2.Size = new System.Drawing.Size(263, 26);
            this.ConsultasToolStripMenuItem2.Text = "-------- Consultas --------";
            // 
            // Bt_VerMovimientoDeCaja
            // 
            this.Bt_VerMovimientoDeCaja.Enabled = false;
            this.Bt_VerMovimientoDeCaja.Name = "Bt_VerMovimientoDeCaja";
            this.Bt_VerMovimientoDeCaja.Size = new System.Drawing.Size(263, 26);
            this.Bt_VerMovimientoDeCaja.Text = "Ver Movimiento de Caja";
            // 
            // SeccionVentasToolStripMenuItem1
            // 
            this.SeccionVentasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_VentanaDeFacturación,
            this.ToolStripSeparator18,
            this.Bt_crearUnaCotización,
            this.ToolStripSeparator19,
            this.Bt_CajearUnaNotaVenta,
            this.ToolStripSeparator22,
            this.ConsultasToolStripMenuItem1,
            this.Bt_VerDocumentosEmitidos,
            this.ToolStripSeparator2,
            this.Bt_VerCotizacionesEmitidas,
            this.ToolStripSeparator20,
            this.Bt_VerCreditoDeClientes,
            this.ToolStripSeparator44,
            this.bt_VerListadoDeClientes});
            this.SeccionVentasToolStripMenuItem1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeccionVentasToolStripMenuItem1.ForeColor = System.Drawing.Color.DimGray;
            this.SeccionVentasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("SeccionVentasToolStripMenuItem1.Image")));
            this.SeccionVentasToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SeccionVentasToolStripMenuItem1.Name = "SeccionVentasToolStripMenuItem1";
            this.SeccionVentasToolStripMenuItem1.Size = new System.Drawing.Size(214, 30);
            this.SeccionVentasToolStripMenuItem1.Text = "Seccion Ventas";
            // 
            // Bt_VentanaDeFacturación
            // 
            this.Bt_VentanaDeFacturación.Enabled = false;
            this.Bt_VentanaDeFacturación.Image = ((System.Drawing.Image)(resources.GetObject("Bt_VentanaDeFacturación.Image")));
            this.Bt_VentanaDeFacturación.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_VentanaDeFacturación.Name = "Bt_VentanaDeFacturación";
            this.Bt_VentanaDeFacturación.Size = new System.Drawing.Size(268, 26);
            this.Bt_VentanaDeFacturación.Text = "Atender una Cotizacion";
            this.Bt_VentanaDeFacturación.ToolTipText = "Esta Opcion abrirá la Ventana de Atención al Cliente\r\npara que puedas Vender, Emi" +
    "tiendo Boleta, Facturas, Notas\r\n";
            // 
            // ToolStripSeparator18
            // 
            this.ToolStripSeparator18.Name = "ToolStripSeparator18";
            this.ToolStripSeparator18.Size = new System.Drawing.Size(265, 6);
            // 
            // Bt_crearUnaCotización
            // 
            this.Bt_crearUnaCotización.Enabled = false;
            this.Bt_crearUnaCotización.Image = ((System.Drawing.Image)(resources.GetObject("Bt_crearUnaCotización.Image")));
            this.Bt_crearUnaCotización.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_crearUnaCotización.Name = "Bt_crearUnaCotización";
            this.Bt_crearUnaCotización.Size = new System.Drawing.Size(268, 26);
            this.Bt_crearUnaCotización.Text = "Crear una Cotización";
            this.Bt_crearUnaCotización.ToolTipText = "Es una Area Especial, para que Puedas \r\nCrear tus Cotizaciones sin Impedimento";
            // 
            // ToolStripSeparator19
            // 
            this.ToolStripSeparator19.Name = "ToolStripSeparator19";
            this.ToolStripSeparator19.Size = new System.Drawing.Size(265, 6);
            // 
            // Bt_CajearUnaNotaVenta
            // 
            this.Bt_CajearUnaNotaVenta.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_CanjearUnaNotaVenta,
            this.ToolStripSeparator37,
            this.Bt_CanjearVariasNotas,
            this.ToolStripSeparator38,
            this.Bt_DuplicarUnaNota});
            this.Bt_CajearUnaNotaVenta.Name = "Bt_CajearUnaNotaVenta";
            this.Bt_CajearUnaNotaVenta.Size = new System.Drawing.Size(268, 26);
            this.Bt_CajearUnaNotaVenta.Text = "Canje de Documentos";
            // 
            // Bt_CanjearUnaNotaVenta
            // 
            this.Bt_CanjearUnaNotaVenta.Enabled = false;
            this.Bt_CanjearUnaNotaVenta.Name = "Bt_CanjearUnaNotaVenta";
            this.Bt_CanjearUnaNotaVenta.Size = new System.Drawing.Size(296, 24);
            this.Bt_CanjearUnaNotaVenta.Text = "Canjear una Nota Venta";
            // 
            // ToolStripSeparator37
            // 
            this.ToolStripSeparator37.Name = "ToolStripSeparator37";
            this.ToolStripSeparator37.Size = new System.Drawing.Size(293, 6);
            // 
            // Bt_CanjearVariasNotas
            // 
            this.Bt_CanjearVariasNotas.Enabled = false;
            this.Bt_CanjearVariasNotas.Name = "Bt_CanjearVariasNotas";
            this.Bt_CanjearVariasNotas.Size = new System.Drawing.Size(296, 24);
            this.Bt_CanjearVariasNotas.Text = "Canjear Varias Notas";
            // 
            // ToolStripSeparator38
            // 
            this.ToolStripSeparator38.Name = "ToolStripSeparator38";
            this.ToolStripSeparator38.Size = new System.Drawing.Size(293, 6);
            // 
            // Bt_DuplicarUnaNota
            // 
            this.Bt_DuplicarUnaNota.Enabled = false;
            this.Bt_DuplicarUnaNota.Name = "Bt_DuplicarUnaNota";
            this.Bt_DuplicarUnaNota.Size = new System.Drawing.Size(296, 24);
            this.Bt_DuplicarUnaNota.Text = "Duplicar Documento Anulado";
            // 
            // ToolStripSeparator22
            // 
            this.ToolStripSeparator22.Name = "ToolStripSeparator22";
            this.ToolStripSeparator22.Size = new System.Drawing.Size(265, 6);
            // 
            // ConsultasToolStripMenuItem1
            // 
            this.ConsultasToolStripMenuItem1.Enabled = false;
            this.ConsultasToolStripMenuItem1.Name = "ConsultasToolStripMenuItem1";
            this.ConsultasToolStripMenuItem1.Size = new System.Drawing.Size(268, 26);
            this.ConsultasToolStripMenuItem1.Text = "------------ Consultas -------";
            // 
            // Bt_VerDocumentosEmitidos
            // 
            this.Bt_VerDocumentosEmitidos.Enabled = false;
            this.Bt_VerDocumentosEmitidos.Name = "Bt_VerDocumentosEmitidos";
            this.Bt_VerDocumentosEmitidos.Size = new System.Drawing.Size(268, 26);
            this.Bt_VerDocumentosEmitidos.Text = "Ver Documentos Emitidos";
            // 
            // ToolStripSeparator2
            // 
            this.ToolStripSeparator2.Name = "ToolStripSeparator2";
            this.ToolStripSeparator2.Size = new System.Drawing.Size(265, 6);
            // 
            // Bt_VerCotizacionesEmitidas
            // 
            this.Bt_VerCotizacionesEmitidas.Enabled = false;
            this.Bt_VerCotizacionesEmitidas.Name = "Bt_VerCotizacionesEmitidas";
            this.Bt_VerCotizacionesEmitidas.Size = new System.Drawing.Size(268, 26);
            this.Bt_VerCotizacionesEmitidas.Text = "Ver Cotizaciones Emitidas";
            // 
            // ToolStripSeparator20
            // 
            this.ToolStripSeparator20.Name = "ToolStripSeparator20";
            this.ToolStripSeparator20.Size = new System.Drawing.Size(265, 6);
            // 
            // Bt_VerCreditoDeClientes
            // 
            this.Bt_VerCreditoDeClientes.Enabled = false;
            this.Bt_VerCreditoDeClientes.Name = "Bt_VerCreditoDeClientes";
            this.Bt_VerCreditoDeClientes.Size = new System.Drawing.Size(268, 26);
            this.Bt_VerCreditoDeClientes.Text = "Ver Credito de Clientes";
            // 
            // ToolStripSeparator44
            // 
            this.ToolStripSeparator44.Name = "ToolStripSeparator44";
            this.ToolStripSeparator44.Size = new System.Drawing.Size(265, 6);
            // 
            // bt_VerListadoDeClientes
            // 
            this.bt_VerListadoDeClientes.Enabled = false;
            this.bt_VerListadoDeClientes.Name = "bt_VerListadoDeClientes";
            this.bt_VerListadoDeClientes.Size = new System.Drawing.Size(268, 26);
            this.bt_VerListadoDeClientes.Text = "Ver Listado de Clientes";
            // 
            // ToolStripSeparator11
            // 
            this.ToolStripSeparator11.Name = "ToolStripSeparator11";
            this.ToolStripSeparator11.Size = new System.Drawing.Size(211, 6);
            // 
            // AdministraciónToolStripMenuItem
            // 
            this.AdministraciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_DevolverProductoConVale,
            this.ToolStripSeparator4,
            this.Bt_EditarUnaVenta,
            this.ToolStripSeparator28,
            this.Bt_ConvertirVentaACredito,
            this.ToolStripSeparator33,
            this.Bt_HacerCierreDeCaja,
            this.ToolStripSeparator34,
            this.Bt_RegistrarUsuarios,
            this.ToolStripSeparator35,
            this.ConsultasToolStripMenuItem5,
            this.Bt_VerCierreDeCaja,
            this.ToolStripSeparator36});
            this.AdministraciónToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdministraciónToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.AdministraciónToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("AdministraciónToolStripMenuItem.Image")));
            this.AdministraciónToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AdministraciónToolStripMenuItem.Name = "AdministraciónToolStripMenuItem";
            this.AdministraciónToolStripMenuItem.Size = new System.Drawing.Size(214, 30);
            this.AdministraciónToolStripMenuItem.Text = "Administración";
            // 
            // Bt_DevolverProductoConVale
            // 
            this.Bt_DevolverProductoConVale.Enabled = false;
            this.Bt_DevolverProductoConVale.Name = "Bt_DevolverProductoConVale";
            this.Bt_DevolverProductoConVale.Size = new System.Drawing.Size(291, 24);
            this.Bt_DevolverProductoConVale.Text = "Devolver producto con Vale";
            // 
            // ToolStripSeparator4
            // 
            this.ToolStripSeparator4.Name = "ToolStripSeparator4";
            this.ToolStripSeparator4.Size = new System.Drawing.Size(288, 6);
            // 
            // Bt_EditarUnaVenta
            // 
            this.Bt_EditarUnaVenta.Enabled = false;
            this.Bt_EditarUnaVenta.Name = "Bt_EditarUnaVenta";
            this.Bt_EditarUnaVenta.Size = new System.Drawing.Size(291, 24);
            this.Bt_EditarUnaVenta.Text = "Editar una Venta";
            // 
            // ToolStripSeparator28
            // 
            this.ToolStripSeparator28.Name = "ToolStripSeparator28";
            this.ToolStripSeparator28.Size = new System.Drawing.Size(288, 6);
            // 
            // Bt_ConvertirVentaACredito
            // 
            this.Bt_ConvertirVentaACredito.Enabled = false;
            this.Bt_ConvertirVentaACredito.Name = "Bt_ConvertirVentaACredito";
            this.Bt_ConvertirVentaACredito.Size = new System.Drawing.Size(291, 24);
            this.Bt_ConvertirVentaACredito.Text = "Convertir Venta a Credito";
            this.Bt_ConvertirVentaACredito.ToolTipText = "Ésta opcion te permite Crear un Crédito \r\na partir de una venta yá Efectuada";
            // 
            // ToolStripSeparator33
            // 
            this.ToolStripSeparator33.Name = "ToolStripSeparator33";
            this.ToolStripSeparator33.Size = new System.Drawing.Size(288, 6);
            // 
            // Bt_HacerCierreDeCaja
            // 
            this.Bt_HacerCierreDeCaja.Enabled = false;
            this.Bt_HacerCierreDeCaja.Name = "Bt_HacerCierreDeCaja";
            this.Bt_HacerCierreDeCaja.Size = new System.Drawing.Size(291, 24);
            this.Bt_HacerCierreDeCaja.Text = "Hacer Cierre de Caja";
            // 
            // ToolStripSeparator34
            // 
            this.ToolStripSeparator34.Name = "ToolStripSeparator34";
            this.ToolStripSeparator34.Size = new System.Drawing.Size(288, 6);
            // 
            // Bt_RegistrarUsuarios
            // 
            this.Bt_RegistrarUsuarios.Enabled = false;
            this.Bt_RegistrarUsuarios.Name = "Bt_RegistrarUsuarios";
            this.Bt_RegistrarUsuarios.Size = new System.Drawing.Size(291, 24);
            this.Bt_RegistrarUsuarios.Text = "Registrar Usuarios";
            // 
            // ToolStripSeparator35
            // 
            this.ToolStripSeparator35.Name = "ToolStripSeparator35";
            this.ToolStripSeparator35.Size = new System.Drawing.Size(288, 6);
            // 
            // ConsultasToolStripMenuItem5
            // 
            this.ConsultasToolStripMenuItem5.Enabled = false;
            this.ConsultasToolStripMenuItem5.Name = "ConsultasToolStripMenuItem5";
            this.ConsultasToolStripMenuItem5.Size = new System.Drawing.Size(291, 24);
            this.ConsultasToolStripMenuItem5.Text = "------- Consultas ------------";
            // 
            // Bt_VerCierreDeCaja
            // 
            this.Bt_VerCierreDeCaja.Enabled = false;
            this.Bt_VerCierreDeCaja.Name = "Bt_VerCierreDeCaja";
            this.Bt_VerCierreDeCaja.Size = new System.Drawing.Size(291, 24);
            this.Bt_VerCierreDeCaja.Text = "Ver Cierre de Caja";
            // 
            // ToolStripSeparator36
            // 
            this.ToolStripSeparator36.Name = "ToolStripSeparator36";
            this.ToolStripSeparator36.Size = new System.Drawing.Size(288, 6);
            // 
            // ToolStripSeparator13
            // 
            this.ToolStripSeparator13.Name = "ToolStripSeparator13";
            this.ToolStripSeparator13.Size = new System.Drawing.Size(211, 6);
            // 
            // SeccionAlmacenToolStripMenuItem1
            // 
            this.SeccionAlmacenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripSeparator31,
            this.ConsultasToolStripMenuItem3,
            this.ToolStripSeparator25,
            this.bt_VerExploradorDeProductos,
            this.ToolStripSeparator26,
            this.bt_VerMovimientoDeProductos,
            this.ToolStripSeparator1,
            this.Bt_ReporteDeProductos});
            this.SeccionAlmacenToolStripMenuItem1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeccionAlmacenToolStripMenuItem1.ForeColor = System.Drawing.Color.DimGray;
            this.SeccionAlmacenToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("SeccionAlmacenToolStripMenuItem1.Image")));
            this.SeccionAlmacenToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SeccionAlmacenToolStripMenuItem1.Name = "SeccionAlmacenToolStripMenuItem1";
            this.SeccionAlmacenToolStripMenuItem1.Size = new System.Drawing.Size(214, 30);
            this.SeccionAlmacenToolStripMenuItem1.Text = "Seccion Almacen";
            // 
            // ToolStripSeparator31
            // 
            this.ToolStripSeparator31.Name = "ToolStripSeparator31";
            this.ToolStripSeparator31.Size = new System.Drawing.Size(299, 6);
            // 
            // ConsultasToolStripMenuItem3
            // 
            this.ConsultasToolStripMenuItem3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ConsultasToolStripMenuItem3.Name = "ConsultasToolStripMenuItem3";
            this.ConsultasToolStripMenuItem3.Size = new System.Drawing.Size(302, 26);
            this.ConsultasToolStripMenuItem3.Text = "------ Consultas ---------";
            // 
            // ToolStripSeparator25
            // 
            this.ToolStripSeparator25.Name = "ToolStripSeparator25";
            this.ToolStripSeparator25.Size = new System.Drawing.Size(299, 6);
            // 
            // bt_VerExploradorDeProductos
            // 
            this.bt_VerExploradorDeProductos.Enabled = false;
            this.bt_VerExploradorDeProductos.Image = ((System.Drawing.Image)(resources.GetObject("bt_VerExploradorDeProductos.Image")));
            this.bt_VerExploradorDeProductos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.bt_VerExploradorDeProductos.Name = "bt_VerExploradorDeProductos";
            this.bt_VerExploradorDeProductos.Size = new System.Drawing.Size(302, 26);
            this.bt_VerExploradorDeProductos.Text = "Ver Explorador de Productos";
            // 
            // ToolStripSeparator26
            // 
            this.ToolStripSeparator26.Name = "ToolStripSeparator26";
            this.ToolStripSeparator26.Size = new System.Drawing.Size(299, 6);
            // 
            // bt_VerMovimientoDeProductos
            // 
            this.bt_VerMovimientoDeProductos.Enabled = false;
            this.bt_VerMovimientoDeProductos.Image = ((System.Drawing.Image)(resources.GetObject("bt_VerMovimientoDeProductos.Image")));
            this.bt_VerMovimientoDeProductos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.bt_VerMovimientoDeProductos.Name = "bt_VerMovimientoDeProductos";
            this.bt_VerMovimientoDeProductos.Size = new System.Drawing.Size(302, 26);
            this.bt_VerMovimientoDeProductos.Text = "Ver Movimiento de Productos";
            // 
            // ToolStripSeparator1
            // 
            this.ToolStripSeparator1.Name = "ToolStripSeparator1";
            this.ToolStripSeparator1.Size = new System.Drawing.Size(299, 6);
            // 
            // Bt_ReporteDeProductos
            // 
            this.Bt_ReporteDeProductos.Enabled = false;
            this.Bt_ReporteDeProductos.Image = ((System.Drawing.Image)(resources.GetObject("Bt_ReporteDeProductos.Image")));
            this.Bt_ReporteDeProductos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_ReporteDeProductos.Name = "Bt_ReporteDeProductos";
            this.Bt_ReporteDeProductos.Size = new System.Drawing.Size(302, 26);
            this.Bt_ReporteDeProductos.Text = "Reporte de Productos";
            // 
            // ToolStripSeparator15
            // 
            this.ToolStripSeparator15.Name = "ToolStripSeparator15";
            this.ToolStripSeparator15.Size = new System.Drawing.Size(211, 6);
            // 
            // MantenimientoToolStripMenuItem
            // 
            this.MantenimientoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_LimpiarTemporalesDeGuia,
            this.toolStripSeparator14,
            this.Bt_LimpiarTemporalesDeVenta,
            this.toolStripSeparator21,
            this.Bt_MantenimientoCategoria,
            this.toolStripSeparator27,
            this.Bt_MantenimientoMarca});
            this.MantenimientoToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MantenimientoToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.MantenimientoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("MantenimientoToolStripMenuItem.Image")));
            this.MantenimientoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MantenimientoToolStripMenuItem.Name = "MantenimientoToolStripMenuItem";
            this.MantenimientoToolStripMenuItem.Size = new System.Drawing.Size(214, 30);
            this.MantenimientoToolStripMenuItem.Text = "Mantenimiento";
            // 
            // Bt_LimpiarTemporalesDeGuia
            // 
            this.Bt_LimpiarTemporalesDeGuia.Name = "Bt_LimpiarTemporalesDeGuia";
            this.Bt_LimpiarTemporalesDeGuia.Size = new System.Drawing.Size(288, 24);
            this.Bt_LimpiarTemporalesDeGuia.Text = "Limpiar Temporales de Guia";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(285, 6);
            // 
            // Bt_LimpiarTemporalesDeVenta
            // 
            this.Bt_LimpiarTemporalesDeVenta.Name = "Bt_LimpiarTemporalesDeVenta";
            this.Bt_LimpiarTemporalesDeVenta.Size = new System.Drawing.Size(288, 24);
            this.Bt_LimpiarTemporalesDeVenta.Text = "Limpiar Temporales de Venta";
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(285, 6);
            // 
            // Bt_MantenimientoCategoria
            // 
            this.Bt_MantenimientoCategoria.Name = "Bt_MantenimientoCategoria";
            this.Bt_MantenimientoCategoria.Size = new System.Drawing.Size(288, 24);
            this.Bt_MantenimientoCategoria.Text = "Mantenimiento Categoria";
            // 
            // toolStripSeparator27
            // 
            this.toolStripSeparator27.Name = "toolStripSeparator27";
            this.toolStripSeparator27.Size = new System.Drawing.Size(285, 6);
            // 
            // Bt_MantenimientoMarca
            // 
            this.Bt_MantenimientoMarca.Name = "Bt_MantenimientoMarca";
            this.Bt_MantenimientoMarca.Size = new System.Drawing.Size(288, 24);
            this.Bt_MantenimientoMarca.Text = "Mantenimiento Marca";
            // 
            // Bt_Config
            // 
            this.Bt_Config.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bt_RegistrarMiEmpresa,
            this.ToolStripSeparator7,
            this.Bt_EditarCorrelativos,
            this.ToolStripSeparator8,
            this.Bt_RestringirAcceso,
            this.ToolStripSeparator9,
            this.Bt_EditarTipoDeCambio,
            this.ToolStripSeparator12,
            this.ToolStripSeparator41});
            this.Bt_Config.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_Config.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Config.Image")));
            this.Bt_Config.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_Config.Name = "Bt_Config";
            this.Bt_Config.Size = new System.Drawing.Size(32, 28);
            this.Bt_Config.ToolTipText = "Configuración";
            // 
            // Bt_RegistrarMiEmpresa
            // 
            this.Bt_RegistrarMiEmpresa.Enabled = false;
            this.Bt_RegistrarMiEmpresa.Name = "Bt_RegistrarMiEmpresa";
            this.Bt_RegistrarMiEmpresa.Size = new System.Drawing.Size(237, 24);
            this.Bt_RegistrarMiEmpresa.Text = "Editar Mi Empresa";
            // 
            // ToolStripSeparator7
            // 
            this.ToolStripSeparator7.Name = "ToolStripSeparator7";
            this.ToolStripSeparator7.Size = new System.Drawing.Size(234, 6);
            // 
            // Bt_EditarCorrelativos
            // 
            this.Bt_EditarCorrelativos.Enabled = false;
            this.Bt_EditarCorrelativos.Name = "Bt_EditarCorrelativos";
            this.Bt_EditarCorrelativos.Size = new System.Drawing.Size(237, 24);
            this.Bt_EditarCorrelativos.Text = "Editar Correlativos";
            // 
            // ToolStripSeparator8
            // 
            this.ToolStripSeparator8.Name = "ToolStripSeparator8";
            this.ToolStripSeparator8.Size = new System.Drawing.Size(234, 6);
            // 
            // Bt_RestringirAcceso
            // 
            this.Bt_RestringirAcceso.Enabled = false;
            this.Bt_RestringirAcceso.Name = "Bt_RestringirAcceso";
            this.Bt_RestringirAcceso.Size = new System.Drawing.Size(237, 24);
            this.Bt_RestringirAcceso.Text = "Restringir Acceso";
            // 
            // ToolStripSeparator9
            // 
            this.ToolStripSeparator9.Name = "ToolStripSeparator9";
            this.ToolStripSeparator9.Size = new System.Drawing.Size(234, 6);
            // 
            // Bt_EditarTipoDeCambio
            // 
            this.Bt_EditarTipoDeCambio.Enabled = false;
            this.Bt_EditarTipoDeCambio.Name = "Bt_EditarTipoDeCambio";
            this.Bt_EditarTipoDeCambio.Size = new System.Drawing.Size(237, 24);
            this.Bt_EditarTipoDeCambio.Text = "Editar Tipo de Cambio";
            // 
            // ToolStripSeparator12
            // 
            this.ToolStripSeparator12.Name = "ToolStripSeparator12";
            this.ToolStripSeparator12.Size = new System.Drawing.Size(234, 6);
            // 
            // ToolStripSeparator41
            // 
            this.ToolStripSeparator41.Name = "ToolStripSeparator41";
            this.ToolStripSeparator41.Size = new System.Drawing.Size(234, 6);
            // 
            // Bt_Configu
            // 
            this.Bt_Configu.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Configu.Image")));
            this.Bt_Configu.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Bt_Configu.Name = "Bt_Configu";
            this.Bt_Configu.Size = new System.Drawing.Size(32, 28);
            this.Bt_Configu.ToolTipText = "Notificaciones, se actualiza cada 5 Segundos";
            // 
            // GfToolStripMenuItem
            // 
            this.GfToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("GfToolStripMenuItem.Image")));
            this.GfToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.GfToolStripMenuItem.Name = "GfToolStripMenuItem";
            this.GfToolStripMenuItem.Size = new System.Drawing.Size(32, 28);
            // 
            // bt_salidadinero
            // 
            this.bt_salidadinero.Enabled = false;
            this.bt_salidadinero.Image = ((System.Drawing.Image)(resources.GetObject("bt_salidadinero.Image")));
            this.bt_salidadinero.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.bt_salidadinero.Name = "bt_salidadinero";
            this.bt_salidadinero.Size = new System.Drawing.Size(32, 28);
            this.bt_salidadinero.ToolTipText = "********** Registrar Gastos ************\r\nRegistra desde aqui todos los Gastos qu" +
    "e Hagas\r\nque puedan Afectar al Cierre de Caja";
            // 
            // LiToolStripMenuItem
            // 
            this.LiToolStripMenuItem.Enabled = false;
            this.LiToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("LiToolStripMenuItem.Image")));
            this.LiToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.LiToolStripMenuItem.Name = "LiToolStripMenuItem";
            this.LiToolStripMenuItem.Size = new System.Drawing.Size(36, 28);
            // 
            // bt_EntradaDinero
            // 
            this.bt_EntradaDinero.Enabled = false;
            this.bt_EntradaDinero.Image = ((System.Drawing.Image)(resources.GetObject("bt_EntradaDinero.Image")));
            this.bt_EntradaDinero.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.bt_EntradaDinero.Name = "bt_EntradaDinero";
            this.bt_EntradaDinero.Size = new System.Drawing.Size(32, 28);
            this.bt_EntradaDinero.ToolTipText = "*********** Registrar Otros Ingresos *************\r\nRegistra desde Aqui otros Ing" +
    "resos De Dinero\r\nque puedan Afectar a tu caja.";
            // 
            // btn_minimi
            // 
            this.btn_minimi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minimi.FlatAppearance.BorderSize = 0;
            this.btn_minimi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_minimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minimi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_minimi.ForeColor = System.Drawing.Color.White;
            this.btn_minimi.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimi.Image")));
            this.btn_minimi.Location = new System.Drawing.Point(1260, 9);
            this.btn_minimi.Name = "btn_minimi";
            this.btn_minimi.Size = new System.Drawing.Size(32, 32);
            this.btn_minimi.TabIndex = 6;
            this.btn_minimi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_minimi.UseVisualStyleBackColor = true;
            this.btn_minimi.Click += new System.EventHandler(this.btn_minimi_Click);
            // 
            // PicLogo
            // 
            this.PicLogo.BackColor = System.Drawing.Color.Transparent;
            this.PicLogo.ForeColor = System.Drawing.Color.Black;
            this.PicLogo.Image = ((System.Drawing.Image)(resources.GetObject("PicLogo.Image")));
            this.PicLogo.Location = new System.Drawing.Point(0, 0);
            this.PicLogo.Name = "PicLogo";
            this.PicLogo.Size = new System.Drawing.Size(172, 55);
            this.PicLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicLogo.TabIndex = 3;
            this.PicLogo.TabStop = false;
            // 
            // PanelLateral
            // 
            this.PanelLateral.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.PanelLateral.BackColor = System.Drawing.Color.WhiteSmoke;
            this.PanelLateral.Controls.Add(this.label1);
            this.PanelLateral.Controls.Add(this.label3);
            this.PanelLateral.Controls.Add(this.PicUser_2);
            this.PanelLateral.Controls.Add(this.bt_DocEmitidos);
            this.PanelLateral.Controls.Add(this.bt_cliente);
            this.PanelLateral.Controls.Add(this.bt_almacen);
            this.PanelLateral.Controls.Add(this.Bt_cotizar);
            this.PanelLateral.Controls.Add(this.Bt_ventas);
            this.PanelLateral.Controls.Add(this.btn_hide);
            this.PanelLateral.Controls.Add(this.bt_compras);
            this.PanelLateral.Controls.Add(this.Dtp_FechaHoy);
            this.PanelLateral.Controls.Add(this.lbl_miperfil);
            this.PanelLateral.Controls.Add(this.lbl_Rol);
            this.PanelLateral.Controls.Add(this.lbl_user);
            this.PanelLateral.Controls.Add(this.PicUser);
            this.PanelLateral.Location = new System.Drawing.Point(0, 56);
            this.PanelLateral.Name = "PanelLateral";
            this.PanelLateral.Size = new System.Drawing.Size(40, 643);
            this.PanelLateral.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Gainsboro;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 641);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 2);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Gainsboro;
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Location = new System.Drawing.Point(39, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1, 643);
            this.label3.TabIndex = 404;
            // 
            // PicUser_2
            // 
            this.PicUser_2.Image = ((System.Drawing.Image)(resources.GetObject("PicUser_2.Image")));
            this.PicUser_2.Location = new System.Drawing.Point(4, 49);
            this.PicUser_2.Name = "PicUser_2";
            this.PicUser_2.Size = new System.Drawing.Size(33, 44);
            this.PicUser_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicUser_2.TabIndex = 403;
            this.PicUser_2.TabStop = false;
            // 
            // bt_DocEmitidos
            // 
            this.bt_DocEmitidos.Enabled = false;
            this.bt_DocEmitidos.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.bt_DocEmitidos.FlatAppearance.BorderSize = 0;
            this.bt_DocEmitidos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.bt_DocEmitidos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.bt_DocEmitidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_DocEmitidos.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_DocEmitidos.ForeColor = System.Drawing.Color.DimGray;
            this.bt_DocEmitidos.Image = ((System.Drawing.Image)(resources.GetObject("bt_DocEmitidos.Image")));
            this.bt_DocEmitidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_DocEmitidos.Location = new System.Drawing.Point(3, 337);
            this.bt_DocEmitidos.Name = "bt_DocEmitidos";
            this.bt_DocEmitidos.Size = new System.Drawing.Size(238, 32);
            this.bt_DocEmitidos.TabIndex = 402;
            this.bt_DocEmitidos.Text = "       Ver Facturas y Otras Ventas";
            this.bt_DocEmitidos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_DocEmitidos.UseVisualStyleBackColor = true;
            // 
            // bt_cliente
            // 
            this.bt_cliente.Enabled = false;
            this.bt_cliente.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.bt_cliente.FlatAppearance.BorderSize = 0;
            this.bt_cliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.bt_cliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.bt_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_cliente.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_cliente.ForeColor = System.Drawing.Color.DimGray;
            this.bt_cliente.Image = ((System.Drawing.Image)(resources.GetObject("bt_cliente.Image")));
            this.bt_cliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_cliente.Location = new System.Drawing.Point(4, 302);
            this.bt_cliente.Name = "bt_cliente";
            this.bt_cliente.Size = new System.Drawing.Size(238, 32);
            this.bt_cliente.TabIndex = 401;
            this.bt_cliente.Text = "       Listado de Clientes";
            this.bt_cliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_cliente.UseVisualStyleBackColor = true;
            // 
            // bt_almacen
            // 
            this.bt_almacen.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.bt_almacen.FlatAppearance.BorderSize = 0;
            this.bt_almacen.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.bt_almacen.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.bt_almacen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_almacen.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_almacen.ForeColor = System.Drawing.Color.DimGray;
            this.bt_almacen.Image = ((System.Drawing.Image)(resources.GetObject("bt_almacen.Image")));
            this.bt_almacen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_almacen.Location = new System.Drawing.Point(3, 264);
            this.bt_almacen.Name = "bt_almacen";
            this.bt_almacen.Size = new System.Drawing.Size(238, 32);
            this.bt_almacen.TabIndex = 400;
            this.bt_almacen.Text = "      Almacen de Productos";
            this.bt_almacen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_almacen.UseVisualStyleBackColor = true;
            this.bt_almacen.Click += new System.EventHandler(this.bt_almacen_Click);
            // 
            // Bt_cotizar
            // 
            this.Bt_cotizar.Enabled = false;
            this.Bt_cotizar.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.Bt_cotizar.FlatAppearance.BorderSize = 0;
            this.Bt_cotizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.Bt_cotizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.Bt_cotizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bt_cotizar.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_cotizar.ForeColor = System.Drawing.Color.DimGray;
            this.Bt_cotizar.Image = ((System.Drawing.Image)(resources.GetObject("Bt_cotizar.Image")));
            this.Bt_cotizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Bt_cotizar.Location = new System.Drawing.Point(3, 229);
            this.Bt_cotizar.Name = "Bt_cotizar";
            this.Bt_cotizar.Size = new System.Drawing.Size(238, 32);
            this.Bt_cotizar.TabIndex = 399;
            this.Bt_cotizar.Text = "      Crear Cotizaciones";
            this.Bt_cotizar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Bt_cotizar.UseVisualStyleBackColor = true;
            // 
            // Bt_ventas
            // 
            this.Bt_ventas.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.Bt_ventas.FlatAppearance.BorderSize = 0;
            this.Bt_ventas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.Bt_ventas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.Bt_ventas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bt_ventas.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_ventas.ForeColor = System.Drawing.Color.DimGray;
            this.Bt_ventas.Image = ((System.Drawing.Image)(resources.GetObject("Bt_ventas.Image")));
            this.Bt_ventas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Bt_ventas.Location = new System.Drawing.Point(3, 194);
            this.Bt_ventas.Name = "Bt_ventas";
            this.Bt_ventas.Size = new System.Drawing.Size(238, 32);
            this.Bt_ventas.TabIndex = 398;
            this.Bt_ventas.Text = "      Ventana de Ventas";
            this.Bt_ventas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Bt_ventas.UseVisualStyleBackColor = true;
            this.Bt_ventas.Click += new System.EventHandler(this.Bt_ventas_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_hide.FlatAppearance.BorderSize = 0;
            this.btn_hide.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SkyBlue;
            this.btn_hide.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btn_hide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hide.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.Image = ((System.Drawing.Image)(resources.GetObject("btn_hide.Image")));
            this.btn_hide.Location = new System.Drawing.Point(9, 4);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(24, 34);
            this.btn_hide.TabIndex = 21;
            this.btn_hide.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_hide.UseVisualStyleBackColor = true;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // bt_compras
            // 
            this.bt_compras.Enabled = false;
            this.bt_compras.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.bt_compras.FlatAppearance.BorderSize = 0;
            this.bt_compras.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.bt_compras.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.bt_compras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_compras.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_compras.ForeColor = System.Drawing.Color.DimGray;
            this.bt_compras.Image = ((System.Drawing.Image)(resources.GetObject("bt_compras.Image")));
            this.bt_compras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_compras.Location = new System.Drawing.Point(3, 159);
            this.bt_compras.Name = "bt_compras";
            this.bt_compras.Size = new System.Drawing.Size(238, 32);
            this.bt_compras.TabIndex = 397;
            this.bt_compras.Text = "      Registra tus Compras";
            this.bt_compras.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_compras.UseVisualStyleBackColor = true;
            // 
            // Dtp_FechaHoy
            // 
            this.Dtp_FechaHoy.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Dtp_FechaHoy.Location = new System.Drawing.Point(51, 591);
            this.Dtp_FechaHoy.Name = "Dtp_FechaHoy";
            this.Dtp_FechaHoy.Size = new System.Drawing.Size(115, 20);
            this.Dtp_FechaHoy.TabIndex = 7;
            this.Dtp_FechaHoy.Visible = false;
            // 
            // lbl_miperfil
            // 
            this.lbl_miperfil.AutoSize = true;
            this.lbl_miperfil.BackColor = System.Drawing.Color.Transparent;
            this.lbl_miperfil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_miperfil.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_miperfil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbl_miperfil.Location = new System.Drawing.Point(93, 133);
            this.lbl_miperfil.Name = "lbl_miperfil";
            this.lbl_miperfil.Size = new System.Drawing.Size(67, 20);
            this.lbl_miperfil.TabIndex = 15;
            this.lbl_miperfil.Text = "Mi perfil";
            this.lbl_miperfil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_Rol
            // 
            this.lbl_Rol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_Rol.AutoSize = true;
            this.lbl_Rol.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_Rol.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Rol.Location = new System.Drawing.Point(19, 559);
            this.lbl_Rol.Name = "lbl_Rol";
            this.lbl_Rol.Size = new System.Drawing.Size(10, 13);
            this.lbl_Rol.TabIndex = 3;
            this.lbl_Rol.Text = "-";
            this.lbl_Rol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_user
            // 
            this.lbl_user.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_user.Location = new System.Drawing.Point(59, 107);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(142, 20);
            this.lbl_user.TabIndex = 14;
            this.lbl_user.Text = "Erwin Rodriguez";
            this.lbl_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PicUser
            // 
            this.PicUser.Image = ((System.Drawing.Image)(resources.GetObject("PicUser.Image")));
            this.PicUser.Location = new System.Drawing.Point(89, 29);
            this.PicUser.Name = "PicUser";
            this.PicUser.Size = new System.Drawing.Size(71, 75);
            this.PicUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicUser.TabIndex = 4;
            this.PicUser.TabStop = false;
            // 
            // Frm_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1344, 700);
            this.Controls.Add(this.PanelLateral);
            this.Controls.Add(this.Pnl_Menu);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Frm_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Microsell Likte";
            this.Load += new System.EventHandler(this.Frm_Principal_Load);
            this.Pnl_Menu.ResumeLayout(false);
            this.Pnl_Menu.PerformLayout();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicLogo)).EndInit();
            this.PanelLateral.ResumeLayout(false);
            this.PanelLateral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        internal System.Windows.Forms.Panel Pnl_Menu;
        private System.Windows.Forms.Button btn_cerrar;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem bt_MenuPrinci;
        internal System.Windows.Forms.ToolStripMenuItem SeccionComprasToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RegistrarUnaCompra;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator16;
        internal System.Windows.Forms.ToolStripMenuItem Bt_EliminarFacturaCompra;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator17;
        internal System.Windows.Forms.ToolStripMenuItem ConsultasToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem Bt_AbrirExploradorDeCompras;
        internal System.Windows.Forms.ToolStripMenuItem Bt_AbrirExploradorDeProveedores;
        internal System.Windows.Forms.ToolStripMenuItem VerComprasACreditoToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator10;
        internal System.Windows.Forms.ToolStripMenuItem SeccionCajaSToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem Bt_AperturarCajaDelDia;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator23;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RegistrarGastos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator24;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RegistrarOtrosIngresos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator3;
        internal System.Windows.Forms.ToolStripMenuItem ConsultasToolStripMenuItem2;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VerMovimientoDeCaja;
        internal System.Windows.Forms.ToolStripMenuItem SeccionVentasToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VentanaDeFacturación;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator18;
        internal System.Windows.Forms.ToolStripMenuItem Bt_crearUnaCotización;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator19;
        internal System.Windows.Forms.ToolStripMenuItem Bt_CajearUnaNotaVenta;
        internal System.Windows.Forms.ToolStripMenuItem Bt_CanjearUnaNotaVenta;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator37;
        internal System.Windows.Forms.ToolStripMenuItem Bt_CanjearVariasNotas;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator38;
        internal System.Windows.Forms.ToolStripMenuItem Bt_DuplicarUnaNota;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator22;
        internal System.Windows.Forms.ToolStripMenuItem ConsultasToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VerDocumentosEmitidos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator2;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VerCotizacionesEmitidas;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator20;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VerCreditoDeClientes;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator44;
        internal System.Windows.Forms.ToolStripMenuItem bt_VerListadoDeClientes;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator11;
        internal System.Windows.Forms.ToolStripMenuItem AdministraciónToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem Bt_DevolverProductoConVale;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator4;
        internal System.Windows.Forms.ToolStripMenuItem Bt_EditarUnaVenta;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator28;
        internal System.Windows.Forms.ToolStripMenuItem Bt_ConvertirVentaACredito;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator33;
        internal System.Windows.Forms.ToolStripMenuItem Bt_HacerCierreDeCaja;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator34;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RegistrarUsuarios;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator35;
        internal System.Windows.Forms.ToolStripMenuItem ConsultasToolStripMenuItem5;
        internal System.Windows.Forms.ToolStripMenuItem Bt_VerCierreDeCaja;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator36;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator13;
        internal System.Windows.Forms.ToolStripMenuItem SeccionAlmacenToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator31;
        internal System.Windows.Forms.ToolStripMenuItem ConsultasToolStripMenuItem3;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator25;
        internal System.Windows.Forms.ToolStripMenuItem bt_VerExploradorDeProductos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator26;
        internal System.Windows.Forms.ToolStripMenuItem bt_VerMovimientoDeProductos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
        internal System.Windows.Forms.ToolStripMenuItem Bt_ReporteDeProductos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator15;
        internal System.Windows.Forms.ToolStripMenuItem MantenimientoToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem Bt_LimpiarTemporalesDeGuia;
        internal System.Windows.Forms.ToolStripMenuItem Bt_LimpiarTemporalesDeVenta;
        internal System.Windows.Forms.ToolStripMenuItem Bt_MantenimientoCategoria;
        internal System.Windows.Forms.ToolStripMenuItem Bt_MantenimientoMarca;
        internal System.Windows.Forms.ToolStripMenuItem Bt_Config;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RegistrarMiEmpresa;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator7;
        internal System.Windows.Forms.ToolStripMenuItem Bt_EditarCorrelativos;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator8;
        internal System.Windows.Forms.ToolStripMenuItem Bt_RestringirAcceso;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator9;
        internal System.Windows.Forms.ToolStripMenuItem Bt_EditarTipoDeCambio;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator12;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator41;
        internal System.Windows.Forms.ToolStripMenuItem Bt_Configu;
        internal System.Windows.Forms.ToolStripMenuItem GfToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem bt_salidadinero;
        internal System.Windows.Forms.ToolStripMenuItem LiToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem bt_EntradaDinero;
        private System.Windows.Forms.Button btn_minimi;
        internal System.Windows.Forms.PictureBox PicLogo;
        internal System.Windows.Forms.Panel PanelLateral;
        internal System.Windows.Forms.PictureBox PicUser_2;
        internal System.Windows.Forms.Button bt_DocEmitidos;
        internal System.Windows.Forms.Button bt_cliente;
        internal System.Windows.Forms.Button bt_almacen;
        internal System.Windows.Forms.Button Bt_cotizar;
        internal System.Windows.Forms.Button Bt_ventas;
        private System.Windows.Forms.Button btn_hide;
        internal System.Windows.Forms.Button bt_compras;
        internal System.Windows.Forms.DateTimePicker Dtp_FechaHoy;
        internal System.Windows.Forms.Label lbl_miperfil;
        internal System.Windows.Forms.Label lbl_Rol;
        internal System.Windows.Forms.Label lbl_user;
        internal System.Windows.Forms.PictureBox PicUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator27;
    }
}

