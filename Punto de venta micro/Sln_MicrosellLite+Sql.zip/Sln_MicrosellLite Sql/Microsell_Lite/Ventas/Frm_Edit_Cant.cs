﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Microsell_Lite.Ventas
{
    public partial class Frm_Edit_Cant : Form
    {
        public Frm_Edit_Cant()
        {
            InitializeComponent();
        }

        private void Frm_Edit_Precio_Load(object sender, EventArgs e)
        {

        }
    }
}
